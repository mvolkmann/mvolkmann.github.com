require 'active_record'

class Cd < ActiveRecord::Base
  has_many :tracks,
           :order => "id ASC", 
           :dependent => true 
end
