require 'active_record'

class Artist < ActiveRecord::Base
  has_many :cds, 
           :order => "title ASC",
           :dependent => true 
     
  def self.starts_with(starts)      
    if starts 
      Artist.find(:all, 
        :conditions => ["name like ?", "#{starts}%"], 
        :order => "name ASC")
    else
      Artist.find(:all, :order => "name ASC")
    end
  end
end
