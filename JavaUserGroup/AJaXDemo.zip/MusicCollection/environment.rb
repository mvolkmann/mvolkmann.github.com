require 'active_record' 

# Add the models directory to the LOAD_PATH.
base_dir = File.dirname(__FILE__)
$:.unshift("#{base_dir}/models")

# Load the models.
require 'Artist'
require 'Cd'
require 'Track'

# Connect to the database.
ActiveRecord::Base.establish_connection( 
  :adapter => 'mysql', 
  :host => 'localhost', 
  :database => 'music', 
  :username => 'root', 
  :password => '' 
) 

