require '../environment'

require 'rexml/document'
require 'rexml/streamlistener'
require 'rexml/xpath'

# Constants
ITUNES_XML = 'iTunes Music Library.xml'

#-------------------------------------------------------------------------------

# REXML event listener (similar to SAX)
class MyListener
  include REXML::StreamListener
  
  def escape_string(string)
    #string.gsub("'", "\\\\'")
    string.gsub("'", "\\'")
  end

  # Reset attributes in preparation for next track.
  def reset_attributes
    @album = "unknown"
    @artist = "unknown"
    @track_name = nil
    @track_number = "?"
    @rating = 0
    @time = 0
  end
  
  def store_track
    return if @track_name == nil
    
    artist = Artist.find_first("name='#{@artist}'")
    if artist == nil
      artist = Artist.create(:name=>@artist)
      puts "added Artist #{artist.name}"
    end
  
    cd = Cd.find_first("artist_id=#{artist.id} and title='#{@album}'")
    if cd == nil
      # TODO: don't know how to get year yet
      cd = Cd.create(:title=>@album, :artist_id=>artist.id)
      puts "added CD #{cd.title}"
    end
  
    track = Track.create(
      :id=>@track_number,
      :name=>@track_name,
      :cd_id=>cd.id,
      :time=>@time,
      :rating=>@rating)
   
    reset_attributes
  end

  def tag_end(name)
    case name
      when 'dict'
        store_track if @track_id # all the track attributes should be set now
      when 'key' # holds track attribute name
        @key = @last_text
        #puts "tag_end: @key = #{@key}"
      when 'integer', 'string', 'date' # holds track attribute value
        value = @last_text
        case @key
          when 'Album'
            @album = value
          when 'Artist'
            if value =~ /^The\s*./ # starts with "The "
              value = value[4..-1] + ', The'
            end
            @artist = value
          when 'Track ID'
            @track_id = value
          when 'Name'
            @track_name = value
          when 'Track Number'
            @track_number = value
          when 'Rating'
            @rating = value.to_i / 20
          when 'Total Time'
            @time = value.to_i
          else
            # do nothing
        end # case key
    end # case name
  end # def tag_end
  
  def tag_start(name, attrs)
    reset_attributes if name == 'plist'
  end
  
  def text(text)
    @last_text = escape_string(text)
    #puts "text: @last_text = #{@last_text}"
  end
  
end

#-------------------------------------------------------------------------------

begin
  Artist.delete_all
  Cd.delete_all
  Track.delete_all
  
  REXML::Document.parse_stream(File.new(ITUNES_XML), MyListener.new())
rescue Mysql::Error => e
  puts "Error! #{e.error}"
end
