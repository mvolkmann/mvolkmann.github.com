class CD
  include Comparable
  
  @@next_uid = 1

  attr_accessor :uid # the unique identifier of this CD
  attr_accessor :title # the title of this CD
  attr_accessor :year # the year of this CD
  attr_accessor :tracks # the tracks on this CD

  def initialize(title, year)
    @uid = @@next_uid
    @@next_uid += 1
    @title = title
    @year = year
    @tracks = {}
  end
    
  def to_s
    "CD: title=#{@title}"
  end
  
  def <=>(other)
    @uid <=> other.uid
  end
  
end