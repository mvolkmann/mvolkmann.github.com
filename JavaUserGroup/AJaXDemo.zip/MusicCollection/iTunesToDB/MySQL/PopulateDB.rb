require 'mysql'

require 'rexml/document'
require 'rexml/streamlistener'
require 'rexml/xpath'

require 'Artist'
require 'CD'
require 'Track'

# Constants
DATABASE = 'music'
HOST = 'localhost'
ITUNES_XML = 'iTunes Music Library.xml'
PASSWORD = ''
USERNAME = 'root'

#-------------------------------------------------------------------------------

# REXML event listener (similar to SAX)
class MyListener
  include REXML::StreamListener
  
  def initialize(conn)
    @conn = conn
    @artists = {}
  end

  def escape_string(string)
    string.gsub("'", "\\\\'")
  end

  # Reset attributes in preparation for next track.
  def reset_attributes
    @album = "unknown"
    @artist = "unknown"
    @track_name = nil
    @track_number = "?"
    @rating = 0
    @time = 0
  end
  
  def store_track
    return if @track_name == nil
    
    artist = @artists[@artist]
    if artist == nil
      artist = @artists[@artist] = Artist.new(@artist)
      sql = "insert into artists (id, name) values ('#{artist.uid}', '#{artist.name}')"
      #puts "Artist sql = #{sql}"
      @conn.query(sql)
      puts "added #{artist}"
    end
  
    cd = artist.cds[@album]
    if cd == nil
      cd = artist.cds[@album] = CD.new(@album, nil) # don't know how to get year yet
      sql = "insert into cds (id, title, artist_id) values ('#{cd.uid}', '#{cd.title}', '#{artist.uid}')"
      #puts "CD sql = #{sql}"
      @conn.query(sql)
      #puts "added #{cd}"
    end
  
    track = Track.new(@track_number, @track_name, @time, @rating)
    cd.tracks[@track_number] = track
    sql = "insert into tracks (id, name, cd_id, time, rating) values ('#{track.uid}', '#{track.name}', '#{cd.uid}', '#{track.time}', '#{track.rating}')"
    #puts "Track sql = #{sql}"
    @conn.query(sql)
    
    reset_attributes
  end

  def tag_end(name)
    case name
      when 'dict'
        store_track if @track_id # all the track attributes should be set now
      when 'key' # holds track attribute name
        @key = @last_text
        #puts "tag_end: @key = #{@key}"
      when 'integer', 'string', 'date' # holds track attribute value
        value = @last_text
        case @key
          when 'Album'
            @album = value
          when 'Artist'
            if value =~ /^The\s*./ # starts with "The "
              value = value[4..-1] + ', The'
            end
            @artist = value
          when 'Track ID'
            @track_id = value
          when 'Name'
            @track_name = value
          when 'Track Number'
            @track_number = value
          when 'Rating'
            @rating = value.to_i / 20
          when 'Total Time'
            @time = value.to_i
          else
            # do nothing
        end # case key
    end # case name
  end # def tag_end
  
  def tag_start(name, attrs)
    reset_attributes if name == 'plist'
  end
  
  def text(text)
    @last_text = escape_string(text)
    #puts "text: @last_text = #{@last_text}"
  end
  
end

#-------------------------------------------------------------------------------

begin
  conn = Mysql.new(HOST, USERNAME, PASSWORD, DATABASE)
  
  # Delete all the rows from the databases tables.
  conn.query("delete from artists")
  conn.query("delete from cds")
  conn.query("delete from tracks")
  
  REXML::Document.parse_stream(File.new(ITUNES_XML), MyListener.new(conn))
rescue Mysql::Error => e
  puts "Error! #{e.error}"
ensure
  conn.close if conn
end
