class Artist
  include Comparable
  
  @@next_uid = 1

  attr_accessor :uid # the unique identifier of this artist
  attr_accessor :name # the name of this artist
  attr_accessor :cds # the CDs by this artist

  def initialize(name)
    @uid = @@next_uid
    @@next_uid += 1
    @name = name
    @cds = {}
  end
  
  def to_s
    "Artist: name=#{@name}"
  end
  
  def <=>(other)
    @uid <=> other.uid
  end
  
end