class Track
  include Comparable
  
  @@next_uid = 1

  attr_accessor :uid # the unique identifier of this track
  attr_accessor :number # the number of the track on its CD
  attr_accessor :name # the name of the track
  attr_accessor :time # the duration of the track in mm:ss format
  attr_accessor :rating # the rating of the track from one to five stars
  
  def initialize(number, name, time, rating)
    @uid = @@next_uid
    @@next_uid += 1
    @number = number
    @name = name
    @time = time
    @rating = rating
  end
    
  def to_s
    "Track: name=#{@name}"
  end
  
  def <=>(other)
    @uid <=> other.uid
  end

end