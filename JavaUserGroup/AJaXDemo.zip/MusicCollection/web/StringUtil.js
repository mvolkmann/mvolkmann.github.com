// This contains utility functions that operate on strings.

// Removes space characters at the beginning of a string.
function ltrim(text) {
  i = 0;
  while (text.charAt(i) == ' ') i++;
  return text.substring(i);
}

// Replaces runs of whitespace with single spaces.
function normalize(string) {
  var array = string.split(/\s+/);
  return array.join(" ");
}