// This contains utility functions make working with DHTML easier.

// Adds an option to the end of a select.
function addOption(select, option) {
  if (isIE()) {
    select.add(option);
  } else {
    select.add(option, null);
  }
}

// Removes all the options from a given select component.
function clearSelect(select) {
  while (select.length > 0) {
    select.remove(0);
  }
}

// Delete all the rows in a given table except the header row.
function clearTable(table) {
  rowCount = table.rows.length;
  for (i = rowCount - 1; i > 0; i--) {
    table.deleteRow(i);
  }
}

// Gets the text inside a given DOM element.
// TODO: This should really concatenate the values
//       of all text nodes inside the element.
function getText(element) {
  return element.firstChild.nodeValue;
}

// Highlights the characters at the end of an input field
// starting from a given position.
function highlightInput(input, start) {
  totalLength = input.value.length;
  if (isIE()) {
    range = input.createTextRange();
    range.moveStart("character", start);
    range.select();
  } else {
    input.setSelectionRange(start, input.value.length);
  }
}

// Determines if the web browser is IE.
function isIE() {
  var browserName = navigator.appName; 
  return browserName == "Microsoft Internet Explorer";
}

// Logs a message to a text area with an id of "log"
// for debugging purposes.
function log(message) {
  //document.getElementById("log").value += message + "\n";
}

function netscapePermissions() {
  var browserName = navigator.appName; 
  if (browserName == "Netscape") {
    netscape.security.PrivilegeManager.enablePrivilege(
      "UniversalBrowserRead");
  }
}

// Sends an asynchronous HTTP request to a given URL
// whose response will be sent to a given handler.
function send(url, handler) {
  // XMLHttpRequest is used to send asynchronous HTTP requests.
  // Firefox seems to require creating a new XMLHttpRequest object
  // for each request.
  xhr = new XMLHttpRequest(); // from Sarissa

  xhr.onreadystatechange = handler;

  log("send: opening " + url);
  async = true;
  xhr.open("GET", url, async);

  log("send: sending to " + url);
  body = null;
  xhr.send(body);

  return xhr;
}
