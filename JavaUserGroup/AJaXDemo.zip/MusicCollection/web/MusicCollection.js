// Keycodes used by event handling functions.
var backspaceKeycode = 8;
var ctrlKeycode = 17;
var downArrowKeycode = 40;
var shiftKeycode = 16;

// Base URL of asynchronous HTTP requests.
var baseURL = "http://localhost:2000/music/";

// Keeps track of whether the Ctrl key is currently down.
var ctrlKeyDown = false;

// The characters of the artist name that the user typed.
var lastArtistPrefix = "";

// Holds an XMLHttpRequest object that is used to
// send asynchronous requests to a server.
var xhr = null;

// Handles keydown events in the artist input field.
function artistKeydown(event, component) {
  //log("artistKeydown: keyCode = " + event.keyCode);
  if (event.keyCode == ctrlKeycode) ctrlKeyDown = true;
  if (event.keyCode == downArrowKeycode) {
    // Move focus from artistInput to artistSelect.
    document.getElementById("artistSelect").focus();
  }
}

// Handles keyup events in the artist input field.
function artistKeyup(event, component) {
  //log("artistKeyup: keyCode = " + event.keyCode);
  // For example, the user may have pressed Ctrl-P to print.
  // At this point ctrlKeyDown could be true and
  // event.keyCode could be the code for 'P'.
  if (!ctrlKeyDown) getArtists(event, component);
  if (event.keyCode == ctrlKeycode) ctrlKeyDown = false;
}

// Handles selections of artists in the artist select component.
function artistSelected(component) {
  index = component.selectedIndex;
  value = component.options[index].text;

  // Copy selected value to text input field.
  document.getElementById("artistInput").value = value;

  getCDs(); // asynchronously
}

// Handles selections of CDs in the CD select component.
function cdSelected(component) {
  index = component.selectedIndex;
  cdId = component.options[index].value;
  getTracks(cdId); // asynchronously
}

// Sends an asynchronous request to obtain
// a list of artists whose name begins with
// the prefix entered in a text input component.
function getArtists(event, component) {
  //log("getArtists: keyCode = " + event.keyCode);
  if (event.keyCode == shiftKeycode) return;

  if (event.keyCode == backspaceKeycode) {
    artistPrefix = lastArtistPrefix.substring
      (0, lastArtistPrefix.length - 1);
  } else {
    artistPrefix = ltrim(component.value); // in StringUtil.js
  }

  log("getArtists: artistPrefix = " + artistPrefix);
  lastArtistPrefix = artistPrefix

  if (artistPrefix.length == 0) {
    component.value = "";
    clearSelect(document.getElementById("artistSelect"));
    clearSelect(document.getElementById("cdSelect"));
    clearTable(document.getElementById("trackTable"));
  } else {
    url = baseURL + "artist?starts=" + artistPrefix;
    //log("getArtist: sending to " + url);
    xhr = send(url, handleArtists);
  }
}

// Sends an asynchronous request to obtain
// a list of CDs by the artist selected in a select component.
function getCDs() {
  select = document.getElementById("artistSelect");
  index = select.selectedIndex;
  option = select.options[index];
  artistId = option.value
  url = baseURL + "artist?id=" + artistId + "&deep";
  log("getCDs: sending to " + url);
  xhr = send(url, handleCDs);
}

// Sends an asynchronous request to obtain
// a list of tracks on a CD selected in a select component.
function getTracks(cdId) {
  url = baseURL + "cd?id=" + cdId + "&deep";
  log("getTracks: sending to " + url);
  xhr = send(url, handleTracks);
}

// Handles the response from asynchronous requests
// for information about artists
// whose name begins with a given prefix.
function handleArtists() {
  if (xhr.readyState == 4) {
    log("handleArtists: got response");
    headersString = xhr.getAllResponseHeaders();
    log("headersString = " + headersString);

    //headersArray = headersString.split("\n");
    //for (i = 0; i < headersArray.length; i++) {
    //  log("header: " + headersArray[i]);
    //}
    //log("server = " + xhr.getResponseHeader("Server"));

    doc = xhr.responseXML;
    //log("handleArtists: xml = " + Sarissa.serialize(doc));

    try {

    if (doc.documentElement == null) {
      alert("Is the server running?");
      return;
    }

    doc.setProperty("SelectionLanguage", "XPath");
    nodes = doc.selectNodes("/artists/artist"); // from Sarissa

    artistSelect = document.getElementById("artistSelect");
    clearSelect(artistSelect);

    if (nodes.length == 0) return;

    // Add an option to artistSelect for each artist.
    for (i = 0; i < nodes.length; i++) {
      artist = nodes[i];
      name = getText(artist);
      id = artist.getAttribute('id')
      option = new Option(name, id, false, i == 0);
      addOption(artistSelect, option);
    }

    // Set artist text field to first choice.
    input = document.getElementById("artistInput");
    firstArtistName = getText(nodes[0]);
    input.value = firstArtistName;

    // Highlight suffix supplied by search.
    highlightInput(input, lastArtistPrefix.length);

    getCDs();

    } catch (e) {
      log(e);
    }
  }
}

// Handles the response from asynchronous requests
// for information about CDs by an artist.
function handleCDs() {
  if (xhr.readyState == 4) {
    log("handleCDs: got response");
    doc = xhr.responseXML;
    //log("handleCDs: xml = " + Sarissa.serialize(doc));

    doc.setProperty("SelectionLanguage", "XPath");
    nodes = doc.selectNodes("/artist/cd"); // from Sarissa

    select = document.getElementById("cdSelect");
    clearSelect(select);

    firstId = 0;

    // Add an option to cdSelect for each CD.
    for (i = 0; i < nodes.length; i++) {
      cd = nodes[i];
      title = getText(cd.selectSingleNode("title")); // from Sarissa
      id = cd.getAttribute('id');
      if (i == 0) firstId = id;
      option = new Option(title, id, false, i == 0);
      addOption(select, option);
    }

    getTracks(firstId);
  }
}

// Handles the response from asynchronous requests
// for information about tracks on a CD.
function handleTracks() {
  if (xhr.readyState == 4) {
    log("handleTracks: got response");
    doc = xhr.responseXML;
    //log("handleTracks: xml = " + Sarissa.serialize(doc));

    doc.setProperty("SelectionLanguage", "XPath");
    nodes = doc.selectNodes("/cd/track"); // from Sarissa

    table = document.getElementById("trackTable");

    clearTable(table);

    // Add a row to trackTable for each track.
    for (i = 0; i < nodes.length; i++) {
      track = nodes[i];
      name = getText(track);
      id = track.getAttribute('id');
      rating = track.getAttribute('rating');

      row = table.insertRow(i + 1);
      row.bgColor = "white";

      cell = row.insertCell(0); // track number
      cell.align = "right"
      cell.innerHTML = i + 1;

      cell = row.insertCell(1); // track name
      cell.innerHTML = name;
      if (rating >= 4) cell.className = "favorite";

      cell = row.insertCell(2); // track rating
      cell.align = "center"
      cell.innerHTML = rating;
    }
  }
}
