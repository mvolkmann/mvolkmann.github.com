require 'net/http'
require "rexml/document"
require 'test/unit'

include REXML

class MusicServerTest < Test::Unit::TestCase

  BASE_URL = 'http://localhost:2000/music/'

  def get(url_suffix)
    url = "#{BASE_URL}#{url_suffix}"
    Net::HTTP.get(URI.parse(url))
  end

  def test_artist_by_id
    response = get('artist?id=96&deep')
    #puts "response =\n#{response}"
    doc = Document.new response
    
    name = XPath.first(doc, '/artist/name')
    assert_not_nil(name, 'artist element has no name child element')
    assert_equal("Apple, Fiona", name.text(), 'incorrect artist name')
    
    cds = XPath.match(doc, '/artist/cd')
    assert_equal(2, cds.length, 'incorrect number of CDs')
    
    title = XPath.first(cds[0], 'title')
    assert_equal("Tidal", title.text(), 'incorrect CD title')
    
    title = XPath.first(cds[1], 'title')
    assert_equal("When The Pawn...", title.text(), 'incorrect CD title')
  end

  def test_cd_by_id
    response = get('cd?id=163&deep')
    doc = Document.new response
    
    title = XPath.first(doc, '/cd/title')
    assert_not_nil(title, 'cd element has no title child element')
    assert_equal("When The Pawn...", title.text(), 'incorrect CD title')
    
    tracks = XPath.match(doc, '/cd/track')
    assert_equal(10, tracks.length, 'incorrect number of CDs')
    
    assert_equal("On The Bound", tracks[0].text(), 'incorrect track name')
  end

  def test_track_by_id
    response = get('track?id=767')
    doc = Document.new response
    
    track = XPath.first(doc, '/track')
    assert_equal("On The Bound", track.text(), 'incorrect track name')
    
    # returns an array of matching attributes ... only one in this case
    attrs = XPath.match(doc, '/track/@rating')
    assert_equal('3', attrs[0].value, 'incorrect track rating')
  end

end
