#!/usr/bin/ruby

puts 'require environment'
require '../environment'

puts 'require rexml'
require 'rexml/document'
include REXML
# Add to_s method to Element class from REXML.
class Element
  def to_s
    s = '';  write(s);  s
  end
end

puts 'require webrick'
require 'webrick'
include WEBrick

puts 'requires completed'

SERVLET_HOST = 'localhost'
SERVLET_PORT = 2000
SERVLET_NAME = 'music'

class MusicServlet < HTTPServlet::AbstractServlet

  # A new servlet instance is created to service each request
  # so currently a new database connection is being created for each.
  # TODO: Consider using a pool of database connections.
  # TODO: See http://segment7.net/projects/ruby/WEBrick/servlets.html
  def initialize(server)
    super(server)
  end

  # Reload the servlet for every request
  # so changes can be tested without restarting the server.
  #def MusicServlet.get_instance config, *options
  #  load __FILE__
  #  MusicServlet.new config, *options
  #end

  def do_POST(req, res)
    puts 'MusicServlet.do_POST called'
  end
  
  def do_PUT(req, res)
    puts 'MusicServlet.do_PUT called'
  end
  
  def do_DELETE(req, res)
    puts 'MusicServlet.do_DELETE called'
  end
  
  def do_GET(req, res)
    #puts "extra path info. is #{req.path_info}"
  
    #puts "query parameters are:"
    #req.query.each do |key, value|
    #  puts "#{key} = #{value}"
    #end
    
    resource_type = req.path_info[1..-1] # remove first character
    resource_id = req.query['id']
    starts = req.query['starts']
    @deep = req.query['deep']
  
    res['Content-Type'] = 'text/xml'

    # Get current time plus one hour in GMT.
    t = Time.now.gmtime + 60*60

    # Format the time for an "Expires" HTTP response header.
    res['Expires'] = t.strftime("%a, %d %b %Y %H:%M:%S GMT")

    res.body = case resource_type
      when 'artist'
        if resource_id and resource_id.size > 0
          get_artist(resource_id).to_s
        else
          get_all_artists(starts).to_s
        end
      when 'cd'
        get_cd(resource_id).to_s
      when 'track'
        get_track(resource_id).to_s
      else
        "unsupported resource type #{resource_type}"
    end
    
    #puts "response =\n#{res.body}"
  end
  
  def get_all_artists(starts)
    artists_element = Element.new('artists')

    artists = Artist.starts_with(starts)
    
    artists.each do |artist|
      artist_element = Element.new('artist', artists_element)
      artist_element.add_attribute('id', artist.id)
      artist_element.add_attribute(
        'href', get_resource_url('artist', artist.id))
      artist_element.add_text(artist.name)
    end
    
    artists_element
  end
  
  def get_artist(artist_id)
    artist = Artist.find(artist_id)
    return "no artist with id #{artist_id} found" if artist == nil
    
    artist_element = Element.new('artist')
    artist_element.add_attribute('id', artist_id)
    name_element = Element.new('name', artist_element)
    name_element.add_text(artist.name)
    
    artist.cds.each do |cd|
      cd_element = if @deep
        artist_element.add_element(get_cd(cd.id))
      else
        Element.new('cd', artist_element)
      end
      cd_element.add_attribute('id', cd.id)
      #cd.add_attribute('year', cd.year)
      cd_element.add_attribute('href', get_resource_url('cd', cd.id)) if not @deep
    end
    
    artist_element
  end
  
  def get_cd(cd_id)
    cd = Cd.find(cd_id)
    return "no cd with id #{cd_id} found" if cd == nil
    
    cd_element = Element.new('cd')
    cd_element.add_attribute('id', cd.id)
    #puts "year of #{cd.title} is #{cd.year}"
    #cd_element.add_attribute('year', cd.year)
    cd_element.add_attribute('artistId', cd.artist_id)
    title_element = Element.new('title', cd_element)
    title_element.add_text(cd.title)
    
    cd.tracks.each do |track|
      track_element = if @deep
        cd_element.add_element(get_track(track.id))
      else
        Element.new('track', cd_element)
      end
      track_element.add_attribute('href', get_resource_url('track', track.id)) if not @deep
    end
    
    cd_element
  end
  
  def get_track(track_id)
    track = Track.find(track_id)
    return "no track with id #{track_id} found" if track == nil
    
    track_element = Element.new('track')
    track_element.add_attribute('id', track.id)
    track_element.add_attribute('cd_id', track.cd_id)
    track_element.add_attribute('rating', track.rating)
    track_element.add_text(track.name)
    
    track_element
  end
  
  def get_resource_url(type, id)
    "http://#{SERVLET_HOST}:#{SERVLET_PORT}/#{SERVLET_NAME}/#{type}?id=#{id}"
  end
    
end

# Create WEBrick server.
# Configure so files in DocumentRoot can be accessed
# with the URL http://localhost:{SERVLET_PORT}/{file}
config = {
  :DocumentRoot => '/AJaX/MusicCollection/web',
  :FancyIndexing => true, # If URI refers to a directory, list the contents.
  :Port => SERVLET_PORT
}
server = HTTPServer.new(config)

# Dump all the configuration options just to see what's there.
#server.config.each do |key, value|
#  puts "config: #{key} = #{value}"
#end

# Add mime type for XHTML.
mimeTypes = server.config[:MimeTypes]
mimeTypes['xhtml'] = 'text/html'
#mimeTypes.keys.sort.each do |key|
#  puts "mime type: #{key} = #{mimeTypes[key]}"
#end

# Allow the server to be stopped with Ctrl-c.
trap('INT') { server.shutdown }
trap('TERM') { server.shutdown }

server.mount("/#{SERVLET_NAME}", MusicServlet)
server.start
