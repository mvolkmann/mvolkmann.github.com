#!/usr/bin/ruby

puts 'require mysql'
require 'mysql'

puts 'require rexml'
require 'rexml/document'
include REXML
# Add to_s method to Element class from REXML.
class Element
  def to_s
    s = '';  write(s);  s
  end
end

puts 'require webrick'
require 'webrick'
include WEBrick

puts 'requires completed'

SERVLET_HOST = 'localhost'
SERVLET_PORT = 2000
SERVLET_NAME = 'music'

class MusicServlet < HTTPServlet::AbstractServlet

  DATABASE = 'music'
  DB_HOST = 'localhost'
  DB_USERNAME = 'root'
  DB_PASSWORD = ''
  
  # A new servlet instance is created to service each request
  # so currently a new database connection is being created for each.
  # TODO: Consider using a pool of database connections.
  # TODO: See http://segment7.net/projects/ruby/WEBrick/servlets.html
  def initialize(server)
    super(server)
    @conn = Mysql.new(DB_HOST, DB_USERNAME, DB_PASSWORD, DATABASE)
    puts "created a new database connection"
  end

  # Reload the servlet for every request
  # so changes can be tested without restarting the server.
  #def MusicServlet.get_instance config, *options
  #  load __FILE__
  #  MusicServlet.new config, *options
  #end

  def do_POST(req, res)
    puts 'MusicServlet.do_POST called'
  end
  
  def do_PUT(req, res)
    puts 'MusicServlet.do_PUT called'
  end
  
  def do_DELETE(req, res)
    puts 'MusicServlet.do_DELETE called'
  end
  
  def do_GET(req, res)
    puts "extra path info. is #{req.path_info}"
  
    puts "query parameters are:"
    req.query.each do |key, value|
      puts "#{key} = #{value}"
    end
    
    resource_type = req.path_info[1..-1] # remove first character
    resource_id = req.query['id']
    starts = req.query['starts']
    @deep = req.query['deep']
  
    res['Content-Type'] = 'text/xml'
    res.body = case resource_type
      when 'artist'
        if resource_id
          get_artist(resource_id).to_s
        else
          get_all_artists(starts).to_s
        end
      when 'cd'
        get_cd(resource_id).to_s
      when 'track'
        get_track(resource_id).to_s
      else
        "unsupported resource type #{resource_type}"
    end
    
    #puts "response =\n#{res.body}"
  end
  
  def get_all_artists(starts)
    sql = "select * from artists"
    sql += " where name like '#{starts}%'" if starts
    sql += " order by name"
    rs = @conn.query(sql)
    
    artists = Element.new('artists')

    rs.each_hash do |row|
      artist = Element.new('artist', artists)
      id = row['id']
      artist.add_attribute('id', id)
      artist.add_attribute('href', get_resource_url('artist', id))
      artist.add_text(row['name'])
    end
    
    artists
  end
  
  def get_artist(artist_id)
    sql = "select * from artists where id='#{artist_id}'"
    rs = @conn.query(sql)
    return "no artist with id #{artist_id} found" if rs.num_rows == 0
    
    row = rs.fetch_hash
    artist = Element.new('artist')
    artist.add_attribute('id', artist_id)
    name = Element.new('name', artist)
    name.add_text(row['name'])
    
    sql = "select * from cds where artist_id=#{artist_id} order by year"
    rs = @conn.query(sql)
    rs.each_hash do |row|
      cd_id = row['id']
      cd = if @deep
        artist.add_element(get_cd(cd_id))
      else
        Element.new('cd', artist)
      end
      cd.add_attribute('id', cd_id)
      #cd.add_attribute('year', row['year'])
      cd.add_attribute('href', get_resource_url('cd', cd_id)) if not @deep
    end
    
    artist
  end
  
  def get_cd(cd_id)
    sql = "select * from cds where id='#{cd_id}'"
    rs = @conn.query(sql)
    return "no cd with id #{cd_id} found" if rs.num_rows == 0
    
    row = rs.fetch_hash
    cd = Element.new('cd')
    cd.add_attribute('id', cd_id)
    #year = row['year']
    #puts "year of #{row['title']} is #{year}"
    #cd.add_attribute('year', year)
    cd.add_attribute('artist_id', row['artist_id'])
    title = Element.new('title', cd)
    title.add_text(row['title'])
    
    sql = "select * from tracks where cd_id=#{cd_id}"
    rs = @conn.query(sql)
    rs.each_hash do |row|
      track_id = row['id']
      track = if @deep
        cd.add_element(get_track(track_id))
      else
        Element.new('track', cd)
      end
      track.add_attribute('href', get_resource_url('track', track_id)) if not @deep
    end
    
    cd
  end
  
  def get_track(track_id)
    sql = "select * from tracks where id='#{track_id}'"
    rs = @conn.query(sql)
    return "no track with id #{track_id} found" if rs.num_rows == 0
    
    row = rs.fetch_hash
    track = Element.new('track')
    track.add_attribute('id', track_id)
    track.add_attribute('cd_id', row['cd_id'])
    track.add_attribute('rating', row['rating'])
    track.add_text(row['name'])
    
    track
  end
  
  def get_resource_url(type, id)
    "http://#{SERVLET_HOST}:#{SERVLET_PORT}/#{SERVLET_NAME}/#{type}?id=#{id}"
  end
    
end

# Create WEBrick server.
# Configure so files in DocumentRoot can be accessed
# with the URL http://localhost:{SERVLET_PORT}/{file}
config = {
  :DocumentRoot => '/AJaX/MusicCollection/webpage',
  :FancyIndexing => true, # if URI refers to a directory, list the contents.
  :Port => SERVLET_PORT
}
server = HTTPServer.new(config)

# Dump all the configuration options just to see what's there.
#server.config.each do |key, value|
#  puts "config: #{key} = #{value}"
#end

# Add mime type for XHTML.
mimeTypes = server.config[:MimeTypes]
mimeTypes['xhtml'] = 'text/html'
#mimeTypes.keys.sort.each do |key|
#  puts "mime type: #{key} = #{mimeTypes[key]}"
#end

# Allow the server to be stopped with Ctrl-c.
trap('INT') { server.shutdown }
trap('TERM') { server.shutdown }

server.mount("/#{SERVLET_NAME}", MusicServlet)
server.start
