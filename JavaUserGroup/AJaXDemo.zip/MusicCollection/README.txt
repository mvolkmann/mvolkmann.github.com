Steps to setup
--------------

- to install Ruby,
  download latest version of the One-Click Installer for Windows
  from http://rubyforge.org/projects/rubyinstaller/
  and execute it

- to install Active Record,
  gem install activerecord

Steps to run
------------

- start the MySQL daemon from a command prompt with
  start mysqld --standalone

- create the database
  cd \AJaX\MusicCollection\database
  createdb
  
- populate database from an iTunes XML document
  (only need to do once)
  cd \AJaX\MusicCollection\iTunesToDB
  PopulateDB.rb

- start the Ruby REST server from a command prompt with
  cd \AJaX\MusicCollection\service
  MusicServer.rb

- run unit tests from a command prompt with
  cd \AJaX\MusicCollection\service
  MusicServerTest.rb

- try REST services from a web browser by visiting URLs like these
  http://localhost:2000/music/artist?id=97&deep
  http://localhost:2000/music/artist?starts=Co
  http://localhost:2000/music/cd?id=164&deep
  http://localhost:2000/music/track?id=777

- run the web browser client by visiting
  http://localhost:2000/MusicCollection.xhtml
  * In IE, must allow blocked content for it to work!
    - click warning bar at top of browser window
    - select "Allow Blocked Content..."
  * You may have to go to Tools...Internet Options...Security...Custom Level...
    and enable "Initialize and script ActiveX controls not marked as safe".
    Why?
  * Start typing the name of an artist
    to see list of matching artist names.
