drop database music;
create database music;
use music;

create table artists (
  id int auto_increment,
  name varchar(40),
  primary key (id)
);

create table cds (
  id int auto_increment,
  title varchar(40),
  artist_id varchar(8),
  year int,
  primary key (id)
);

create table tracks (
  id int auto_increment,
  name varchar(40),
  cd_id varchar(8),
  time varchar(5),
  rating int,
  primary key (id)
);

#insert into artists values ("Ani Difranco", "a1");
#insert into artists values ("Sting", "a2");

#insert into cds values ("Knuckle Down", "c1", "a1", 2005);
#insert into cds values ("To The Teeth", "c2", "a1", 1999);
#insert into cds values ("Nothing Like the Sun", "c3", "a2", 1987);
#insert into cds values ("The Soul Cages", "c4", "a2", 1991);
