package com.ociweb.antlr;

import org.antlr.runtime.RecognitionException;

public class MyRecognitionException extends RecognitionException {

    private String msg;

    public MyRecognitionException(String msg) {
        this.msg = msg;
    }

    public String getMessage() { return msg; }

    public void setMessage(String msg) { this.msg = msg; }
}
