package com.ociweb.antlr;

import org.antlr.runtime.BaseRecognizer;
import org.antlr.runtime.RecognitionException;

public class RecognizerHelper {

    private BaseRecognizer recognizer;
    private boolean interactive;

    public RecognizerHelper(BaseRecognizer recognizer) {
        this.recognizer = recognizer;
    }

    // This addresses the following issues
    // that are not handled by BaseRecognizer.reportError.
    // 1) line and column numbers aren't included
    //    when running in interactive mode
    // 2) MyRecognitionException is supported
    public void displayRecognitionError(
        String[] tokenNames, RecognitionException e) {

        //System.out.println(
        //    "RecognizerHelper.displayRecognitionError:\n  called from " +
        //    recognizer.getClass());

        String msg = e instanceof MyRecognitionException ?
            e.getMessage() : recognizer.getErrorMessage(e, tokenNames);
        if (!interactive) msg = recognizer.getErrorHeader(e) + ' ' + msg;
        recognizer.emitErrorMessage(msg);
        //System.out.println("---");
    }

    public boolean isInteractive() {
        return interactive;
    }

    public void setInteractive(boolean interactive) {
        this.interactive = interactive;
    }
}
