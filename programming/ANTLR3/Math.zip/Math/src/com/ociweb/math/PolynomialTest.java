package com.ociweb.math;

import org.junit.*;

import static org.junit.Assert.*;

/**
 * Unit tests for the Polynomial class.
 * @author R. Mark Volkmann, Object Computing, Inc.
 */
public class PolynomialTest {

    public static Polynomial makePolynomial() {
        Polynomial p = new Polynomial();
        p.addTerm(3, "x", 2);
        p.addTerm(-5, "x");
        p.addTerm(7);
        return p;
    }

    @Test public void testEquals() {
        Polynomial p1 = makePolynomial();
        Polynomial p2 = makePolynomial();
        assertEquals(p1, p2);

        Polynomial p3 = new Polynomial();
        p3.addTerm(3, "x", 2);
        p3.addTerm(-6, "x"); // the difference
        p3.addTerm(7);
        assertFalse(p1.equals(p3));
    }

    @Test public void testGetDerivative() {
        Polynomial p = makePolynomial();
        Polynomial actual = p.getDerivative();

        Polynomial expected = new Polynomial();
        expected.addTerm(6, "x", 1);
        expected.addTerm(-5);

        assertEquals(expected, actual);
    }

    @Test public void testGetValue() {
        Polynomial p = makePolynomial();
        assertEquals(7.0, p.getValue(0));
        assertEquals(5.0, p.getValue(1));
        assertEquals(9.0, p.getValue(2));
        assertEquals(15.0, p.getValue(-1));
        assertEquals(29.0, p.getValue(-2));
    }

    @Test public void testToString() {
        Polynomial p = makePolynomial();
        assertEquals("3x^2 - 5x + 7", p.toString());

        p = new Polynomial();
        p.addTerm(3, "x", 2);
        p.addTerm(-1, "x", 1);
        p.addTerm(-5, "x", 0);
        p.addTerm(7);
        assertEquals("3x^2 - x + 2", p.toString());

        p = new Polynomial();
        p.addTerm(-3, "x", -2);
        assertEquals("-3x^-2", p.toString());
    }
}
