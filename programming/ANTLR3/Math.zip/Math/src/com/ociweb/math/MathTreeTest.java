package com.ociweb.math;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import org.antlr.runtime.RecognitionException;
import org.antlr.runtime.tree.CommonTree;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Unit tests for the ANTLR-generated MathTree class.
 * @author R. Mark Volkmann, Object Computing, Inc.
 */
public class MathTreeTest {
    
  private static final String SCRIPT =
    "f(x) = 3x^2 - 5x + 7\n" +
    "print f(1)";

  private Processor processor = new Processor();

  /**
   * Unit test for processAST.
   */
  @Test public void testProcessAST()
  throws IOException, RecognitionException {
    CommonTree ast = processor.getAST(SCRIPT);

    System.out.println("ast = " + ast);

    // Setup to capture stdout.
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    PrintStream newPS = new PrintStream(baos);
    PrintStream oldPS = System.out;
    System.setOut(newPS);

    processor.processAST(ast);

    // Reset stdout.
    System.setOut(oldPS);

    String actual = baos.toString().trim();
    String expected = "5.0";
    assertEquals("correct output", expected, actual);
  }
}
