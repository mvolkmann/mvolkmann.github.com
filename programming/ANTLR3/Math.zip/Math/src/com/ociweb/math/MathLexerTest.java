package com.ociweb.math;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.antlr.runtime.CommonTokenStream;
import org.antlr.runtime.Token;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Unit tests for the ANTLR-generated MathLexer class.
 * @author R. Mark Volkmann, Object Computing, Inc.
 */
public class MathLexerTest {

    private static final String SCRIPT =
        "f(x) = 3x^2 - 5x + 7\n" +
        "print f(1)";

    private Processor processor = new Processor();

    /**
     * Unit test for AST generation.
     */
    @Test public void testGetTokenStream()
    throws IOException {
        CommonTokenStream cts = processor.getTokenStream(SCRIPT);

        // Get the text of all tokens not on the hidden channel.
        List<String> actualList = new ArrayList<String>();
        List<Token> tokens = (List<Token>) cts.getTokens();
        for (Token token : tokens) {
            if (token.getChannel() != Token.HIDDEN_CHANNEL) {
                //System.out.println(token.getText());
                actualList.add(token.getText());
            }
        }

        String[] actual = actualList.toArray(new String[0]);

        String[] expected = {
            "f", "(", "x", ")", "=",
            "3", "x", "^", "2", "-", "5", "x", "+", "7",
            "\n", // not skipped, but written to the hidden channel
            "print", "f", "(", "1", ")"
        };

        /*
           System.out.print("expected = ");
           for (String s : expected) System.out.println(s);
           System.out.println("end");

           System.out.print("  actual = ");
           for (String s : actual) System.out.println(s);
           System.out.println("end");
           */

        assertEquals("correct tokens", expected, actual);
    }
}
