package com.ociweb.math;

import org.junit.*;

import static org.junit.Assert.*;

/**
 * Unit tests for the Function class.
 * @author R. Mark Volkmann, Object Computing, Inc.
 */
public class FunctionTest {

    public static Function makeFunction() {
        Polynomial p = PolynomialTest.makePolynomial();
        return new Function("f", "x", p);
    }

    @Test public void testAdd() {
        Function f1 = makeFunction();

        Polynomial p = new Polynomial();
        p.addTerm(4, "x", 3);
        p.addTerm(8, "x");
        Function f2 = new Function("g", "x", p);

        // Add functions f1 and f2 to get the actual result.
        String newName = "h";
        Function actual = f1.add(newName, f2);

        // Create the expected function result.
        p = new Polynomial();
        p.addTerm(4, "x", 3);
        p.addTerm(3, "x", 2);
        p.addTerm(3, "x");
        p.addTerm(7);
        Function expected = new Function(newName, f1.getVariable(), p);

        assertEquals(expected, actual);
    }

    @Test public void testEquals() {
        Function f1 = makeFunction();
        Function f2 = makeFunction();
        assertEquals(f1, f2);

        Polynomial p = new Polynomial();
        p.addTerm(3, "x", 2);
        p.addTerm(-6, "x"); // the difference
        p.addTerm(7);

        // Test with same names, but different polynomials.
        assertFalse(f1.equals(new Function("f", "x", p)));

        // Test with different names, but same polynomials.
        assertFalse(f1.equals(new Function("g", "x", f1.getPolynomial())));
    }

    @Test public void testSubtract() {
        Function f1 = makeFunction();

        Polynomial p = new Polynomial();
        p.addTerm(4, "x", 3);
        p.addTerm(8, "x");
        Function f2 = new Function("g", "x", p);

        // Add functions f1 and f2 to get the actual result.
        String newName = "h";
        Function actual = f1.subtract(newName, f2);

        // Create the expected function result.
        p = new Polynomial();
        p.addTerm(-4, "x", 3);
        p.addTerm(3, "x", 2);
        p.addTerm(-13, "x");
        p.addTerm(7);
        Function expected = new Function(newName, f1.getVariable(), p);

        assertEquals(expected, actual);
    }

    @Test public void testToString() {
        Function f = makeFunction();
        assertEquals("f(x) = 3x^2 - 5x + 7", f.toString());
    }
}
