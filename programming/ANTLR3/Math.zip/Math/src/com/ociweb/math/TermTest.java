package com.ociweb.math;

import org.junit.*;

import static org.junit.Assert.*;

/**
 * Unit tests for the Term class.
 * @author R. Mark Volkmann, Object Computing, Inc.
 */
public class TermTest {

    @Test public void testCompareTo() {
        assertEquals(1, new Term(3, "x", 2).compareTo(new Term(3, "x", 3)));
        assertEquals(0, new Term(3, "x", 2).compareTo(new Term(3, "x", 2)));
        assertEquals(-1, new Term(3, "x", 2).compareTo(new Term(3, "x", 1)));
    }
    
    @Test public void testEquals() {
        Term t1 = new Term(3, "x", 2);
        Term t2 = new Term(4, "x", 2);
        Term t3 = new Term(3, "y", 2);
        Term t4 = new Term(3, "x", 1);
        Term t5 = new Term(3, "x", 2);

        assertEquals(t1, t1);
        assertFalse(t1.equals(t2));
        assertFalse(t1.equals(t3));
        assertFalse(t1.equals(t4));
        assertEquals(t1, t5);
    }

    @Test public void testGetDerivative() {
        Term term = new Term(3, "x", 2);
        Term expected = new Term(6, "x", 1);
        Term actual = term.getDerivative();
        assertEquals("correct derivative", expected, actual);
    }

    @Test public void testGetValue() {
        // Test handling of positive exponent.
        Term term = new Term(2, "x", 3);
        assertEquals(0.0, term.getValue(0));
        assertEquals(2.0, term.getValue(1));
        assertEquals(16.0, term.getValue(2));
        assertEquals(-2.0, term.getValue(-1));
        assertEquals(-16.0, term.getValue(-2));

        // Test handling of zero exponent.
        term = new Term(2, "x", 0);
        assertEquals(2.0, term.getValue(3));

        // Test handling of negative exponent.
        term = new Term(2, "x", -3);
        assertEquals(0.25, term.getValue(2));
    }

    @Test public void testToString() {
        assertEquals("3", new Term(3).toString());

        assertEquals("x", new Term(1, "x").toString());
        assertEquals("x", new Term("x", 1).toString());
        assertEquals("x", new Term(1, "x", 1).toString());

        assertEquals("3x", new Term(3, "x").toString());
        assertEquals("x^2", new Term("x", 2).toString());
        assertEquals("3x^2", new Term(3, "x", 2).toString());
        assertEquals("-3x^-2", new Term(-3, "x", -2).toString());

        assertEquals("1", new Term("x", 0).toString());
        assertEquals("3", new Term(3, "x", 0).toString());
    }
}
