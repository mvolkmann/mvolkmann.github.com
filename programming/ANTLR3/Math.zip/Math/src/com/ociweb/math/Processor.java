package com.ociweb.math;

import java.io.*;
import java.util.Scanner;
import org.antlr.runtime.*;
import org.antlr.runtime.tree.*;
import org.antlr.stringtemplate.*;

public class Processor {

    public static void main(String[] args)
    throws IOException, RecognitionException {
        if (args.length == 0) {
            new Processor().processInteractive();
        } else if (args.length == 1) { // name of file to process passed in
            new Processor().processFile(args[0]);
        } else { // more than one command-line argument
            System.err.println(
                "usage: java com.ociweb.math.Processor [file-name]");
        }
    }

    private void processFile(String filePath)
    throws IOException, RecognitionException {
        CommonTree ast = getAST(new FileReader(filePath));
        //System.out.println(ast.toStringTree()); // for debugging
        processAST(ast);
    }

    private CommonTree getAST(Reader reader)
    throws IOException, RecognitionException {
        MathParser tokenParser = new MathParser(getTokenStream(reader));
        MathParser.script_return parserResult =
            tokenParser.script(); // start rule method
        reader.close();
        return (CommonTree) parserResult.getTree();
    }

    private CommonTokenStream getTokenStream(Reader reader)
    throws IOException {
        MathLexer lexer = new MathLexer(new ANTLRReaderStream(reader));
        return new CommonTokenStream(lexer);
    }

    // This is public so it can be used by unit tests.
    public void processAST(CommonTree ast) throws RecognitionException {
        MathTree treeParser = new MathTree(new CommonTreeNodeStream(ast));
        treeParser.script();
    }

    private void processInteractive()
    throws IOException, RecognitionException {
        MathTree treeParser =
            new MathTree(null); // a TreeNodeStream will be assigned later
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.print("math> ");
            String line = scanner.nextLine().trim();
            if ("quit".equals(line) || "exit".equals(line)) break;
            processLine(treeParser, line);
        }
    }

    // Note that we can't create a new instance of MathTree for each
    // line processed because it maintains the variable and function Maps.
    // This is public so it can be used by unit tests.
    public void processLine(MathTree treeParser, String line)
    throws IOException, RecognitionException {
        // Run the lexer and token parser on the line.
        MathLexer lexer = new MathLexer(new ANTLRStringStream(line));
        MathParser tokenParser =
            new MathParser(new CommonTokenStream(lexer));
        tokenParser.interactiveMode = true;
        MathParser.statement_return parserResult =
            tokenParser.statement(); // start rule method

        // Use the token parser to retrieve the AST.
        CommonTree ast = (CommonTree) parserResult.getTree();
        if (ast == null) return; // line is empty

        // The next line is here to support ErrorTest.java.
        if (treeParser == null) treeParser = new MathTree(null);
        
        // Use the tree parser to process the AST.
        treeParser.setTreeNodeStream(new CommonTreeNodeStream(ast));
        treeParser.statement(); // start rule method
    }

    // This is only used by unit tests and that's why it's public.
    public CommonTree getAST(String script)
    throws IOException, RecognitionException {
        StringReader sr = new StringReader(script);
        CommonTree ast = getAST(sr);
        sr.close();
        return ast;
    }

    // This is only used by unit tests and that's why it's public.
    public CommonTokenStream getTokenStream(String script)
    throws IOException {
        StringReader sr = new StringReader(script);
        CommonTokenStream ts = getTokenStream(sr);
        sr.close();
        return ts;
    }

} // end of Processor class
