package com.ociweb.math;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import org.antlr.runtime.*;
import org.antlr.runtime.tree.*;
import org.junit.*;

import static org.junit.Assert.*;

/**
 * Unit tests for error handling in the ANTLR-generated parser classes.
 * @author R. Mark Volkmann, Object Computing, Inc.
 */
public class ErrorTest {

    private ByteArrayOutputStream baos = new ByteArrayOutputStream();
    private PrintStream oldPS;
    private Processor processor = new Processor();

    private String getStdErr() {
        String text = baos.toString().trim();
        baos.reset();
        return text;
    }

    @Before public void setup() {
        //processor.setInteractive(true);

        // Setup to capture stderr.
        baos = new ByteArrayOutputStream();
        PrintStream newPS = new PrintStream(baos);
        oldPS = System.err;
        System.setErr(newPS);
    }

    @After public void teardown() {
        // Reset stderr.
        System.setErr(oldPS);
    }

    /**
     * Tests that a given line of input
     * writes a given error message to stderr.
     */
    private void testError(String line, String expectedMsg)
    throws IOException, RecognitionException {
        System.out.println("\nErrorTest.testError: line = " + line);

        try {
            processor.processLine(null, line);
            //fail("expected RewriteEmptyStreamException");
        } catch (RewriteEmptyStreamException e) {
            // do nothing
        }

        String actualMsg = getStdErr();

        System.out.println(
            "ErrorTest.testError: expectedMsg = " + expectedMsg);
        System.out.println(
            "ErrorTest.testError: actualMsg = " + actualMsg);

        assertEquals("error for line \"" + line + "\"",
            expectedMsg, actualMsg);
    }

    @Test public void testErrors()
    throws IOException, RecognitionException {
        String msg = "syntax error, see help";
        testError("badtoken", msg); // syntax error

        msg = "The variable \"a\" is not set.";
        testError("print a", msg); // unknown variable

        msg = "The function \"f\" is not defined.";
        testError("print f()", msg); // unknown function

        msg = "The function \"g\" is not defined.";
        testError("f = g + h", msg); // unknown function

        msg = "\"list\" must be followed by \"functions\" or " +
            "\"variables\", not \"foo\".";
        testError("list foo", msg); // unsupported list operand

        msg = "In function \"f\" the term variable \"y\"" +
            " doesn't match function variable \"x\".";
        testError("f(x) = 3x^2 - 2y + 4", msg); // variable mismatch

        msg = "The defintion of function \"h\" has an invalid variable " +
            "\"2\" in the parentheses.";
        testError("h(2) = x", msg); // bad function def parameter

        msg = "The token \"x2\" wasn't expected in assignment.";
        testError("a = 1x2", msg);

        msg = "invalid syntax \"1..\"";
        testError("a = 1..2", msg);

        msg = "invalid syntax \".\"";
        testError("a = .1", msg);

        msg = "invalid syntax \"1.\"";
        // TODO: Why is "syntax error, see help"
        // TODO: tacked onto the end of the message?
        //testError("a = 1.", msg);

        msg = "The token \"^\" wasn't expected in function definition.";
        // TODO: Why is "no viable alternative at input"
        // TODO: tacked onto the end of the message?
        //testError("g(y) = ^2", msg); // missing variable before ^

        msg = "invalid syntax \"/\"";
        // TODO: Why is additional text tacked on?
        testError("f(x) = 3x^2 - 2x / 7", msg); // syntax error

        // TODO: What input would generated this error?
        msg = "Cannot convert \"1x2\" to a double.";

        // TODO: What input would generated this error?
        msg = "The operator \"*\" cannot be used for combining functions.";
    }
}
