package com.ociweb.math;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import org.antlr.runtime.RecognitionException;
import org.antlr.runtime.tree.CommonTree;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Unit tests for the ANTLR-generated MathParser class.
 * @author R. Mark Volkmann, Object Computing, Inc.
 */
public class MathParserTest {

    private static final String SCRIPT =
        "f(x) = 3x^2 - 5x + 7\n" +
        "print f(1)";

    private Processor processor = new Processor();

    /**
     * Unit test for AST generation.
     */
    @Test public void testGetAST()
        throws IOException, RecognitionException {
        CommonTree ast = processor.getAST(SCRIPT);
        String actual = ast.toStringTree();
        String expected =
            "(DEFINE f x (POLYNOMIAL " +
            "(TERM 3 x 2) - (TERM 5 x) + (TERM 7))) (print (FUNCTION f 1))";
        System.out.println("expected = \"" + expected + '"');
        System.out.println("  actual = \"" + actual + '"');
        assertEquals("correct AST", expected, actual);
    }
}
