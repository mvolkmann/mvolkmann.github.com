// $ANTLR 3.0.1 /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g 2008-03-09 11:23:37
 package com.ociweb.math; 

import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

import org.antlr.runtime.debug.*;
import java.io.IOException;

import org.antlr.runtime.tree.*;

public class MathParserParser extends DebugParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "APOSTROPHE", "ASSERT", "ASSIGN", "BACKSLASH", "CARET", "FUNCTIONS", "HELP", "LEFT_PAREN", "LIST", "PRINT", "RELATION", "RIGHT_PAREN", "SIGN", "VARIABLES", "INTEGER", "FLOAT", "NUMBER", "LETTER", "NAME", "NONCONTROL_CHAR", "STRING_LITERAL", "NEWLINE", "SINGLE_COMMENT", "MULTI_COMMENT", "SPACE", "WHITESPACE", "DIGIT", "SYMBOL", "LOWER", "UPPER", "COMBINE", "DEFINE", "DERIVATIVE", "FUNCTION", "POLYNOMIAL", "TERM"
    };
    public static final int LEFT_PAREN=11;
    public static final int LETTER=21;
    public static final int SPACE=28;
    public static final int SINGLE_COMMENT=26;
    public static final int NONCONTROL_CHAR=23;
    public static final int LIST=12;
    public static final int NUMBER=20;
    public static final int FLOAT=19;
    public static final int RELATION=14;
    public static final int POLYNOMIAL=38;
    public static final int LOWER=32;
    public static final int MULTI_COMMENT=27;
    public static final int CARET=8;
    public static final int BACKSLASH=7;
    public static final int VARIABLES=17;
    public static final int WHITESPACE=29;
    public static final int NEWLINE=25;
    public static final int FUNCTIONS=9;
    public static final int INTEGER=18;
    public static final int DEFINE=35;
    public static final int PRINT=13;
    public static final int FUNCTION=37;
    public static final int HELP=10;
    public static final int UPPER=33;
    public static final int EOF=-1;
    public static final int STRING_LITERAL=24;
    public static final int ASSIGN=6;
    public static final int SYMBOL=31;
    public static final int SIGN=16;
    public static final int ASSERT=5;
    public static final int APOSTROPHE=4;
    public static final int DIGIT=30;
    public static final int NAME=22;
    public static final int COMBINE=34;
    public static final int RIGHT_PAREN=15;
    public static final int DERIVATIVE=36;
    public static final int TERM=39;
    public static final String[] ruleNames = new String[] {
        "invalidRule", "assign", "coefficient", "combine", "define", "derivative", 
        "exponent", "functionEval", "help", "interactiveStatement", "list", 
        "listOption", "polynomial", "print", "printTarget", "script", "statement", 
        "term", "terminator", "value"
    };

    public int ruleLevel = 0;
    public MathParserParser(TokenStream input, int port) {
            super(input, port);
            DebugEventSocketProxy proxy =
                new DebugEventSocketProxy(this, port, adaptor);
            setDebugListener(proxy);
            adaptor.setDebugEventListener(proxy);
            try {
                proxy.handshake();
            }
            catch (IOException ioe) {
                reportError(ioe);
            }

    }
    public MathParserParser(TokenStream input) {
        this(input, DebugEventSocketProxy.DEFAULT_DEBUGGER_PORT);
    }
    public MathParserParser(TokenStream input, DebugEventListener dbg) {
        super(input, dbg);
        adaptor.setDebugEventListener(dbg);
    }

    protected boolean evalPredicate(boolean result, String predicate) {
        dbg.semanticPredicate(result, predicate);
        return result;
    }

    protected DebugTreeAdaptor adaptor =
    	  new DebugTreeAdaptor(null,new CommonTreeAdaptor());
    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = new DebugTreeAdaptor(dbg,adaptor);
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }


    public String[] getTokenNames() { return tokenNames; }
    public String getGrammarFileName() { return "/Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g"; }

     public boolean interactiveMode; 

    public static class assign_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start assign
    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:22:1: assign : NAME ASSIGN value terminator -> ^( ASSIGN NAME value ) ;
    public final assign_return assign() throws RecognitionException {
        assign_return retval = new assign_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token NAME1=null;
        Token ASSIGN2=null;
        value_return value3 = null;

        terminator_return terminator4 = null;


        Object NAME1_tree=null;
        Object ASSIGN2_tree=null;
        RewriteRuleTokenStream stream_NAME=new RewriteRuleTokenStream(adaptor,"token NAME");
        RewriteRuleTokenStream stream_ASSIGN=new RewriteRuleTokenStream(adaptor,"token ASSIGN");
        RewriteRuleSubtreeStream stream_terminator=new RewriteRuleSubtreeStream(adaptor,"rule terminator");
        RewriteRuleSubtreeStream stream_value=new RewriteRuleSubtreeStream(adaptor,"rule value");
        try { dbg.enterRule("assign");
        if ( ruleLevel==0 ) {dbg.commence();}
        ruleLevel++;
        dbg.location(22, 1);

        try {
            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:23:3: ( NAME ASSIGN value terminator -> ^( ASSIGN NAME value ) )
            dbg.enterAlt(1);

            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:23:5: NAME ASSIGN value terminator
            {
            dbg.location(23,5);
            NAME1=(Token)input.LT(1);
            match(input,NAME,FOLLOW_NAME_in_assign89); 
            stream_NAME.add(NAME1);

            dbg.location(23,10);
            ASSIGN2=(Token)input.LT(1);
            match(input,ASSIGN,FOLLOW_ASSIGN_in_assign91); 
            stream_ASSIGN.add(ASSIGN2);

            dbg.location(23,17);
            pushFollow(FOLLOW_value_in_assign93);
            value3=value();
            _fsp--;

            stream_value.add(value3.getTree());
            dbg.location(23,23);
            pushFollow(FOLLOW_terminator_in_assign95);
            terminator4=terminator();
            _fsp--;

            stream_terminator.add(terminator4.getTree());
            dbg.location(23,34);

            // AST REWRITE
            // elements: value, NAME, ASSIGN
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 23:34: -> ^( ASSIGN NAME value )
            {
                dbg.location(23,37);
                // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:23:37: ^( ASSIGN NAME value )
                {
                Object root_1 = (Object)adaptor.nil();
                dbg.location(23,39);
                root_1 = (Object)adaptor.becomeRoot(stream_ASSIGN.next(), root_1);

                dbg.location(23,46);
                adaptor.addChild(root_1, stream_NAME.next());
                dbg.location(23,51);
                adaptor.addChild(root_1, stream_value.next());

                adaptor.addChild(root_0, root_1);
                }

            }



            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        dbg.location(23, 57);

        }
        finally {
            dbg.exitRule("assign");
            ruleLevel--;
            if ( ruleLevel==0 ) {dbg.terminate();}
        }

        return retval;
    }
    // $ANTLR end assign

    public static class coefficient_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start coefficient
    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:25:1: coefficient : NUMBER ;
    public final coefficient_return coefficient() throws RecognitionException {
        coefficient_return retval = new coefficient_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token NUMBER5=null;

        Object NUMBER5_tree=null;

        try { dbg.enterRule("coefficient");
        if ( ruleLevel==0 ) {dbg.commence();}
        ruleLevel++;
        dbg.location(25, 1);

        try {
            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:25:12: ( NUMBER )
            dbg.enterAlt(1);

            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:25:14: NUMBER
            {
            root_0 = (Object)adaptor.nil();

            dbg.location(25,14);
            NUMBER5=(Token)input.LT(1);
            match(input,NUMBER,FOLLOW_NUMBER_in_coefficient112); 
            NUMBER5_tree = (Object)adaptor.create(NUMBER5);
            adaptor.addChild(root_0, NUMBER5_tree);


            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        dbg.location(25, 20);

        }
        finally {
            dbg.exitRule("coefficient");
            ruleLevel--;
            if ( ruleLevel==0 ) {dbg.terminate();}
        }

        return retval;
    }
    // $ANTLR end coefficient

    public static class combine_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start combine
    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:27:1: combine : fn1= NAME ASSIGN fn2= NAME op= SIGN fn3= NAME terminator -> ^( COMBINE $fn1 $op $fn2 $fn3) ;
    public final combine_return combine() throws RecognitionException {
        combine_return retval = new combine_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token fn1=null;
        Token fn2=null;
        Token op=null;
        Token fn3=null;
        Token ASSIGN6=null;
        terminator_return terminator7 = null;


        Object fn1_tree=null;
        Object fn2_tree=null;
        Object op_tree=null;
        Object fn3_tree=null;
        Object ASSIGN6_tree=null;
        RewriteRuleTokenStream stream_SIGN=new RewriteRuleTokenStream(adaptor,"token SIGN");
        RewriteRuleTokenStream stream_NAME=new RewriteRuleTokenStream(adaptor,"token NAME");
        RewriteRuleTokenStream stream_ASSIGN=new RewriteRuleTokenStream(adaptor,"token ASSIGN");
        RewriteRuleSubtreeStream stream_terminator=new RewriteRuleSubtreeStream(adaptor,"rule terminator");
        try { dbg.enterRule("combine");
        if ( ruleLevel==0 ) {dbg.commence();}
        ruleLevel++;
        dbg.location(27, 1);

        try {
            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:28:3: (fn1= NAME ASSIGN fn2= NAME op= SIGN fn3= NAME terminator -> ^( COMBINE $fn1 $op $fn2 $fn3) )
            dbg.enterAlt(1);

            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:28:5: fn1= NAME ASSIGN fn2= NAME op= SIGN fn3= NAME terminator
            {
            dbg.location(28,8);
            fn1=(Token)input.LT(1);
            match(input,NAME,FOLLOW_NAME_in_combine124); 
            stream_NAME.add(fn1);

            dbg.location(28,14);
            ASSIGN6=(Token)input.LT(1);
            match(input,ASSIGN,FOLLOW_ASSIGN_in_combine126); 
            stream_ASSIGN.add(ASSIGN6);

            dbg.location(28,24);
            fn2=(Token)input.LT(1);
            match(input,NAME,FOLLOW_NAME_in_combine130); 
            stream_NAME.add(fn2);

            dbg.location(28,32);
            op=(Token)input.LT(1);
            match(input,SIGN,FOLLOW_SIGN_in_combine134); 
            stream_SIGN.add(op);

            dbg.location(28,41);
            fn3=(Token)input.LT(1);
            match(input,NAME,FOLLOW_NAME_in_combine138); 
            stream_NAME.add(fn3);

            dbg.location(28,47);
            pushFollow(FOLLOW_terminator_in_combine140);
            terminator7=terminator();
            _fsp--;

            stream_terminator.add(terminator7.getTree());
            dbg.location(29,5);

            // AST REWRITE
            // elements: op, fn3, fn1, fn2
            // token labels: op, fn2, fn1, fn3
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleTokenStream stream_op=new RewriteRuleTokenStream(adaptor,"token op",op);
            RewriteRuleTokenStream stream_fn2=new RewriteRuleTokenStream(adaptor,"token fn2",fn2);
            RewriteRuleTokenStream stream_fn1=new RewriteRuleTokenStream(adaptor,"token fn1",fn1);
            RewriteRuleTokenStream stream_fn3=new RewriteRuleTokenStream(adaptor,"token fn3",fn3);
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 29:5: -> ^( COMBINE $fn1 $op $fn2 $fn3)
            {
                dbg.location(29,8);
                // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:29:8: ^( COMBINE $fn1 $op $fn2 $fn3)
                {
                Object root_1 = (Object)adaptor.nil();
                dbg.location(29,10);
                root_1 = (Object)adaptor.becomeRoot(adaptor.create(COMBINE, "COMBINE"), root_1);

                dbg.location(29,18);
                adaptor.addChild(root_1, stream_fn1.next());
                dbg.location(29,23);
                adaptor.addChild(root_1, stream_op.next());
                dbg.location(29,27);
                adaptor.addChild(root_1, stream_fn2.next());
                dbg.location(29,32);
                adaptor.addChild(root_1, stream_fn3.next());

                adaptor.addChild(root_0, root_1);
                }

            }



            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        dbg.location(29, 37);

        }
        finally {
            dbg.exitRule("combine");
            ruleLevel--;
            if ( ruleLevel==0 ) {dbg.terminate();}
        }

        return retval;
    }
    // $ANTLR end combine

    public static class define_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start define
    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:31:1: define : fn= NAME LEFT_PAREN fv= NAME RIGHT_PAREN ASSIGN polynomial[$fn.text,$fv.text] terminator -> ^( DEFINE $fn $fv polynomial ) ;
    public final define_return define() throws RecognitionException {
        define_return retval = new define_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token fn=null;
        Token fv=null;
        Token LEFT_PAREN8=null;
        Token RIGHT_PAREN9=null;
        Token ASSIGN10=null;
        polynomial_return polynomial11 = null;

        terminator_return terminator12 = null;


        Object fn_tree=null;
        Object fv_tree=null;
        Object LEFT_PAREN8_tree=null;
        Object RIGHT_PAREN9_tree=null;
        Object ASSIGN10_tree=null;
        RewriteRuleTokenStream stream_LEFT_PAREN=new RewriteRuleTokenStream(adaptor,"token LEFT_PAREN");
        RewriteRuleTokenStream stream_NAME=new RewriteRuleTokenStream(adaptor,"token NAME");
        RewriteRuleTokenStream stream_RIGHT_PAREN=new RewriteRuleTokenStream(adaptor,"token RIGHT_PAREN");
        RewriteRuleTokenStream stream_ASSIGN=new RewriteRuleTokenStream(adaptor,"token ASSIGN");
        RewriteRuleSubtreeStream stream_terminator=new RewriteRuleSubtreeStream(adaptor,"rule terminator");
        RewriteRuleSubtreeStream stream_polynomial=new RewriteRuleSubtreeStream(adaptor,"rule polynomial");
        try { dbg.enterRule("define");
        if ( ruleLevel==0 ) {dbg.commence();}
        ruleLevel++;
        dbg.location(31, 1);

        try {
            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:32:3: (fn= NAME LEFT_PAREN fv= NAME RIGHT_PAREN ASSIGN polynomial[$fn.text,$fv.text] terminator -> ^( DEFINE $fn $fv polynomial ) )
            dbg.enterAlt(1);

            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:32:5: fn= NAME LEFT_PAREN fv= NAME RIGHT_PAREN ASSIGN polynomial[$fn.text,$fv.text] terminator
            {
            dbg.location(32,7);
            fn=(Token)input.LT(1);
            match(input,NAME,FOLLOW_NAME_in_define174); 
            stream_NAME.add(fn);

            dbg.location(32,13);
            LEFT_PAREN8=(Token)input.LT(1);
            match(input,LEFT_PAREN,FOLLOW_LEFT_PAREN_in_define176); 
            stream_LEFT_PAREN.add(LEFT_PAREN8);

            dbg.location(32,26);
            fv=(Token)input.LT(1);
            match(input,NAME,FOLLOW_NAME_in_define180); 
            stream_NAME.add(fv);

            dbg.location(32,32);
            RIGHT_PAREN9=(Token)input.LT(1);
            match(input,RIGHT_PAREN,FOLLOW_RIGHT_PAREN_in_define182); 
            stream_RIGHT_PAREN.add(RIGHT_PAREN9);

            dbg.location(32,44);
            ASSIGN10=(Token)input.LT(1);
            match(input,ASSIGN,FOLLOW_ASSIGN_in_define184); 
            stream_ASSIGN.add(ASSIGN10);

            dbg.location(33,5);
            pushFollow(FOLLOW_polynomial_in_define190);
            polynomial11=polynomial(fn.getText(), fv.getText());
            _fsp--;

            stream_polynomial.add(polynomial11.getTree());
            dbg.location(33,35);
            pushFollow(FOLLOW_terminator_in_define193);
            terminator12=terminator();
            _fsp--;

            stream_terminator.add(terminator12.getTree());
            dbg.location(34,5);

            // AST REWRITE
            // elements: fv, polynomial, fn
            // token labels: fv, fn
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleTokenStream stream_fv=new RewriteRuleTokenStream(adaptor,"token fv",fv);
            RewriteRuleTokenStream stream_fn=new RewriteRuleTokenStream(adaptor,"token fn",fn);
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 34:5: -> ^( DEFINE $fn $fv polynomial )
            {
                dbg.location(34,8);
                // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:34:8: ^( DEFINE $fn $fv polynomial )
                {
                Object root_1 = (Object)adaptor.nil();
                dbg.location(34,10);
                root_1 = (Object)adaptor.becomeRoot(adaptor.create(DEFINE, "DEFINE"), root_1);

                dbg.location(34,17);
                adaptor.addChild(root_1, stream_fn.next());
                dbg.location(34,21);
                adaptor.addChild(root_1, stream_fv.next());
                dbg.location(34,25);
                adaptor.addChild(root_1, stream_polynomial.next());

                adaptor.addChild(root_0, root_1);
                }

            }



            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        dbg.location(34, 36);

        }
        finally {
            dbg.exitRule("define");
            ruleLevel--;
            if ( ruleLevel==0 ) {dbg.terminate();}
        }

        return retval;
    }
    // $ANTLR end define

    public static class derivative_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start derivative
    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:36:1: derivative : fn= NAME APOSTROPHE LEFT_PAREN RIGHT_PAREN -> ^( DERIVATIVE $fn) ;
    public final derivative_return derivative() throws RecognitionException {
        derivative_return retval = new derivative_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token fn=null;
        Token APOSTROPHE13=null;
        Token LEFT_PAREN14=null;
        Token RIGHT_PAREN15=null;

        Object fn_tree=null;
        Object APOSTROPHE13_tree=null;
        Object LEFT_PAREN14_tree=null;
        Object RIGHT_PAREN15_tree=null;
        RewriteRuleTokenStream stream_LEFT_PAREN=new RewriteRuleTokenStream(adaptor,"token LEFT_PAREN");
        RewriteRuleTokenStream stream_APOSTROPHE=new RewriteRuleTokenStream(adaptor,"token APOSTROPHE");
        RewriteRuleTokenStream stream_NAME=new RewriteRuleTokenStream(adaptor,"token NAME");
        RewriteRuleTokenStream stream_RIGHT_PAREN=new RewriteRuleTokenStream(adaptor,"token RIGHT_PAREN");

        try { dbg.enterRule("derivative");
        if ( ruleLevel==0 ) {dbg.commence();}
        ruleLevel++;
        dbg.location(36, 1);

        try {
            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:37:3: (fn= NAME APOSTROPHE LEFT_PAREN RIGHT_PAREN -> ^( DERIVATIVE $fn) )
            dbg.enterAlt(1);

            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:37:5: fn= NAME APOSTROPHE LEFT_PAREN RIGHT_PAREN
            {
            dbg.location(37,7);
            fn=(Token)input.LT(1);
            match(input,NAME,FOLLOW_NAME_in_derivative225); 
            stream_NAME.add(fn);

            dbg.location(37,13);
            APOSTROPHE13=(Token)input.LT(1);
            match(input,APOSTROPHE,FOLLOW_APOSTROPHE_in_derivative227); 
            stream_APOSTROPHE.add(APOSTROPHE13);

            dbg.location(37,24);
            LEFT_PAREN14=(Token)input.LT(1);
            match(input,LEFT_PAREN,FOLLOW_LEFT_PAREN_in_derivative229); 
            stream_LEFT_PAREN.add(LEFT_PAREN14);

            dbg.location(37,35);
            RIGHT_PAREN15=(Token)input.LT(1);
            match(input,RIGHT_PAREN,FOLLOW_RIGHT_PAREN_in_derivative231); 
            stream_RIGHT_PAREN.add(RIGHT_PAREN15);

            dbg.location(37,47);

            // AST REWRITE
            // elements: fn
            // token labels: fn
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleTokenStream stream_fn=new RewriteRuleTokenStream(adaptor,"token fn",fn);
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 37:47: -> ^( DERIVATIVE $fn)
            {
                dbg.location(37,50);
                // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:37:50: ^( DERIVATIVE $fn)
                {
                Object root_1 = (Object)adaptor.nil();
                dbg.location(37,52);
                root_1 = (Object)adaptor.becomeRoot(adaptor.create(DERIVATIVE, "DERIVATIVE"), root_1);

                dbg.location(37,63);
                adaptor.addChild(root_1, stream_fn.next());

                adaptor.addChild(root_0, root_1);
                }

            }



            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        dbg.location(37, 67);

        }
        finally {
            dbg.exitRule("derivative");
            ruleLevel--;
            if ( ruleLevel==0 ) {dbg.terminate();}
        }

        return retval;
    }
    // $ANTLR end derivative

    public static class exponent_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start exponent
    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:39:1: exponent : CARET NUMBER -> NUMBER ;
    public final exponent_return exponent() throws RecognitionException {
        exponent_return retval = new exponent_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token CARET16=null;
        Token NUMBER17=null;

        Object CARET16_tree=null;
        Object NUMBER17_tree=null;
        RewriteRuleTokenStream stream_CARET=new RewriteRuleTokenStream(adaptor,"token CARET");
        RewriteRuleTokenStream stream_NUMBER=new RewriteRuleTokenStream(adaptor,"token NUMBER");

        try { dbg.enterRule("exponent");
        if ( ruleLevel==0 ) {dbg.commence();}
        ruleLevel++;
        dbg.location(39, 1);

        try {
            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:39:9: ( CARET NUMBER -> NUMBER )
            dbg.enterAlt(1);

            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:39:11: CARET NUMBER
            {
            dbg.location(39,11);
            CARET16=(Token)input.LT(1);
            match(input,CARET,FOLLOW_CARET_in_exponent247); 
            stream_CARET.add(CARET16);

            dbg.location(39,17);
            NUMBER17=(Token)input.LT(1);
            match(input,NUMBER,FOLLOW_NUMBER_in_exponent249); 
            stream_NUMBER.add(NUMBER17);

            dbg.location(39,24);

            // AST REWRITE
            // elements: NUMBER
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 39:24: -> NUMBER
            {
                dbg.location(39,27);
                adaptor.addChild(root_0, stream_NUMBER.next());

            }



            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        dbg.location(39, 33);

        }
        finally {
            dbg.exitRule("exponent");
            ruleLevel--;
            if ( ruleLevel==0 ) {dbg.terminate();}
        }

        return retval;
    }
    // $ANTLR end exponent

    public static class functionEval_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start functionEval
    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:41:1: functionEval : fn= NAME LEFT_PAREN (v= NUMBER | v= NAME ) RIGHT_PAREN -> ^( FUNCTION $fn $v) ;
    public final functionEval_return functionEval() throws RecognitionException {
        functionEval_return retval = new functionEval_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token fn=null;
        Token v=null;
        Token LEFT_PAREN18=null;
        Token RIGHT_PAREN19=null;

        Object fn_tree=null;
        Object v_tree=null;
        Object LEFT_PAREN18_tree=null;
        Object RIGHT_PAREN19_tree=null;
        RewriteRuleTokenStream stream_LEFT_PAREN=new RewriteRuleTokenStream(adaptor,"token LEFT_PAREN");
        RewriteRuleTokenStream stream_NAME=new RewriteRuleTokenStream(adaptor,"token NAME");
        RewriteRuleTokenStream stream_RIGHT_PAREN=new RewriteRuleTokenStream(adaptor,"token RIGHT_PAREN");
        RewriteRuleTokenStream stream_NUMBER=new RewriteRuleTokenStream(adaptor,"token NUMBER");

        try { dbg.enterRule("functionEval");
        if ( ruleLevel==0 ) {dbg.commence();}
        ruleLevel++;
        dbg.location(41, 1);

        try {
            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:42:3: (fn= NAME LEFT_PAREN (v= NUMBER | v= NAME ) RIGHT_PAREN -> ^( FUNCTION $fn $v) )
            dbg.enterAlt(1);

            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:42:5: fn= NAME LEFT_PAREN (v= NUMBER | v= NAME ) RIGHT_PAREN
            {
            dbg.location(42,7);
            fn=(Token)input.LT(1);
            match(input,NAME,FOLLOW_NAME_in_functionEval265); 
            stream_NAME.add(fn);

            dbg.location(42,13);
            LEFT_PAREN18=(Token)input.LT(1);
            match(input,LEFT_PAREN,FOLLOW_LEFT_PAREN_in_functionEval267); 
            stream_LEFT_PAREN.add(LEFT_PAREN18);

            dbg.location(42,24);
            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:42:24: (v= NUMBER | v= NAME )
            int alt1=2;
            try { dbg.enterSubRule(1);
            try { dbg.enterDecision(1);

            int LA1_0 = input.LA(1);

            if ( (LA1_0==NUMBER) ) {
                alt1=1;
            }
            else if ( (LA1_0==NAME) ) {
                alt1=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("42:24: (v= NUMBER | v= NAME )", 1, 0, input);

                dbg.recognitionException(nvae);
                throw nvae;
            }
            } finally {dbg.exitDecision(1);}

            switch (alt1) {
                case 1 :
                    dbg.enterAlt(1);

                    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:42:25: v= NUMBER
                    {
                    dbg.location(42,26);
                    v=(Token)input.LT(1);
                    match(input,NUMBER,FOLLOW_NUMBER_in_functionEval272); 
                    stream_NUMBER.add(v);


                    }
                    break;
                case 2 :
                    dbg.enterAlt(2);

                    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:42:36: v= NAME
                    {
                    dbg.location(42,37);
                    v=(Token)input.LT(1);
                    match(input,NAME,FOLLOW_NAME_in_functionEval278); 
                    stream_NAME.add(v);


                    }
                    break;

            }
            } finally {dbg.exitSubRule(1);}

            dbg.location(42,44);
            RIGHT_PAREN19=(Token)input.LT(1);
            match(input,RIGHT_PAREN,FOLLOW_RIGHT_PAREN_in_functionEval281); 
            stream_RIGHT_PAREN.add(RIGHT_PAREN19);

            dbg.location(42,56);

            // AST REWRITE
            // elements: fn, v
            // token labels: v, fn
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleTokenStream stream_v=new RewriteRuleTokenStream(adaptor,"token v",v);
            RewriteRuleTokenStream stream_fn=new RewriteRuleTokenStream(adaptor,"token fn",fn);
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 42:56: -> ^( FUNCTION $fn $v)
            {
                dbg.location(42,59);
                // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:42:59: ^( FUNCTION $fn $v)
                {
                Object root_1 = (Object)adaptor.nil();
                dbg.location(42,61);
                root_1 = (Object)adaptor.becomeRoot(adaptor.create(FUNCTION, "FUNCTION"), root_1);

                dbg.location(42,70);
                adaptor.addChild(root_1, stream_fn.next());
                dbg.location(42,74);
                adaptor.addChild(root_1, stream_v.next());

                adaptor.addChild(root_0, root_1);
                }

            }



            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        dbg.location(42, 77);

        }
        finally {
            dbg.exitRule("functionEval");
            ruleLevel--;
            if ( ruleLevel==0 ) {dbg.terminate();}
        }

        return retval;
    }
    // $ANTLR end functionEval

    public static class help_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start help
    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:44:1: help : HELP terminator -> HELP ;
    public final help_return help() throws RecognitionException {
        help_return retval = new help_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token HELP20=null;
        terminator_return terminator21 = null;


        Object HELP20_tree=null;
        RewriteRuleTokenStream stream_HELP=new RewriteRuleTokenStream(adaptor,"token HELP");
        RewriteRuleSubtreeStream stream_terminator=new RewriteRuleSubtreeStream(adaptor,"rule terminator");
        try { dbg.enterRule("help");
        if ( ruleLevel==0 ) {dbg.commence();}
        ruleLevel++;
        dbg.location(44, 1);

        try {
            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:44:5: ( HELP terminator -> HELP )
            dbg.enterAlt(1);

            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:44:7: HELP terminator
            {
            dbg.location(44,7);
            HELP20=(Token)input.LT(1);
            match(input,HELP,FOLLOW_HELP_in_help302); 
            stream_HELP.add(HELP20);

            dbg.location(44,12);
            pushFollow(FOLLOW_terminator_in_help304);
            terminator21=terminator();
            _fsp--;

            stream_terminator.add(terminator21.getTree());
            dbg.location(44,23);

            // AST REWRITE
            // elements: HELP
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 44:23: -> HELP
            {
                dbg.location(44,26);
                adaptor.addChild(root_0, stream_HELP.next());

            }



            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        dbg.location(44, 30);

        }
        finally {
            dbg.exitRule("help");
            ruleLevel--;
            if ( ruleLevel==0 ) {dbg.terminate();}
        }

        return retval;
    }
    // $ANTLR end help

    public static class interactiveStatement_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start interactiveStatement
    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:46:1: interactiveStatement : ( help | list );
    public final interactiveStatement_return interactiveStatement() throws RecognitionException {
        interactiveStatement_return retval = new interactiveStatement_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        help_return help22 = null;

        list_return list23 = null;



        try { dbg.enterRule("interactiveStatement");
        if ( ruleLevel==0 ) {dbg.commence();}
        ruleLevel++;
        dbg.location(46, 1);

        try {
            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:46:21: ( help | list )
            int alt2=2;
            try { dbg.enterDecision(2);

            int LA2_0 = input.LA(1);

            if ( (LA2_0==HELP) ) {
                alt2=1;
            }
            else if ( (LA2_0==LIST) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("46:1: interactiveStatement : ( help | list );", 2, 0, input);

                dbg.recognitionException(nvae);
                throw nvae;
            }
            } finally {dbg.exitDecision(2);}

            switch (alt2) {
                case 1 :
                    dbg.enterAlt(1);

                    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:46:23: help
                    {
                    root_0 = (Object)adaptor.nil();

                    dbg.location(46,23);
                    pushFollow(FOLLOW_help_in_interactiveStatement317);
                    help22=help();
                    _fsp--;

                    adaptor.addChild(root_0, help22.getTree());

                    }
                    break;
                case 2 :
                    dbg.enterAlt(2);

                    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:46:30: list
                    {
                    root_0 = (Object)adaptor.nil();

                    dbg.location(46,30);
                    pushFollow(FOLLOW_list_in_interactiveStatement321);
                    list23=list();
                    _fsp--;

                    adaptor.addChild(root_0, list23.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        dbg.location(46, 34);

        }
        finally {
            dbg.exitRule("interactiveStatement");
            ruleLevel--;
            if ( ruleLevel==0 ) {dbg.terminate();}
        }

        return retval;
    }
    // $ANTLR end interactiveStatement

    public static class list_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start list
    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:48:1: list : LIST listOption terminator -> ^( LIST listOption ) ;
    public final list_return list() throws RecognitionException {
        list_return retval = new list_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token LIST24=null;
        listOption_return listOption25 = null;

        terminator_return terminator26 = null;


        Object LIST24_tree=null;
        RewriteRuleTokenStream stream_LIST=new RewriteRuleTokenStream(adaptor,"token LIST");
        RewriteRuleSubtreeStream stream_terminator=new RewriteRuleSubtreeStream(adaptor,"rule terminator");
        RewriteRuleSubtreeStream stream_listOption=new RewriteRuleSubtreeStream(adaptor,"rule listOption");
        try { dbg.enterRule("list");
        if ( ruleLevel==0 ) {dbg.commence();}
        ruleLevel++;
        dbg.location(48, 1);

        try {
            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:49:3: ( LIST listOption terminator -> ^( LIST listOption ) )
            dbg.enterAlt(1);

            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:49:5: LIST listOption terminator
            {
            dbg.location(49,5);
            LIST24=(Token)input.LT(1);
            match(input,LIST,FOLLOW_LIST_in_list333); 
            stream_LIST.add(LIST24);

            dbg.location(49,10);
            pushFollow(FOLLOW_listOption_in_list335);
            listOption25=listOption();
            _fsp--;

            stream_listOption.add(listOption25.getTree());
            dbg.location(49,21);
            pushFollow(FOLLOW_terminator_in_list337);
            terminator26=terminator();
            _fsp--;

            stream_terminator.add(terminator26.getTree());
            dbg.location(49,32);

            // AST REWRITE
            // elements: LIST, listOption
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 49:32: -> ^( LIST listOption )
            {
                dbg.location(49,35);
                // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:49:35: ^( LIST listOption )
                {
                Object root_1 = (Object)adaptor.nil();
                dbg.location(49,37);
                root_1 = (Object)adaptor.becomeRoot(stream_LIST.next(), root_1);

                dbg.location(49,42);
                adaptor.addChild(root_1, stream_listOption.next());

                adaptor.addChild(root_0, root_1);
                }

            }



            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        dbg.location(49, 53);

        }
        finally {
            dbg.exitRule("list");
            ruleLevel--;
            if ( ruleLevel==0 ) {dbg.terminate();}
        }

        return retval;
    }
    // $ANTLR end list

    public static class listOption_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start listOption
    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:51:1: listOption : ( FUNCTIONS | VARIABLES );
    public final listOption_return listOption() throws RecognitionException {
        listOption_return retval = new listOption_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token set27=null;

        Object set27_tree=null;

        try { dbg.enterRule("listOption");
        if ( ruleLevel==0 ) {dbg.commence();}
        ruleLevel++;
        dbg.location(51, 1);

        try {
            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:51:11: ( FUNCTIONS | VARIABLES )
            dbg.enterAlt(1);

            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:
            {
            root_0 = (Object)adaptor.nil();

            dbg.location(51,11);
            set27=(Token)input.LT(1);
            if ( input.LA(1)==FUNCTIONS||input.LA(1)==VARIABLES ) {
                input.consume();
                adaptor.addChild(root_0, adaptor.create(set27));
                errorRecovery=false;
            }
            else {
                MismatchedSetException mse =
                    new MismatchedSetException(null,input);
                dbg.recognitionException(mse);
                recoverFromMismatchedSet(input,mse,FOLLOW_set_in_listOption0);    throw mse;
            }


            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        dbg.location(51, 34);

        }
        finally {
            dbg.exitRule("listOption");
            ruleLevel--;
            if ( ruleLevel==0 ) {dbg.terminate();}
        }

        return retval;
    }
    // $ANTLR end listOption

    public static class polynomial_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start polynomial
    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:54:1: polynomial[String fnt, String fvt] : term[$fnt,$fvt] ( SIGN term[$fnt, $fvt] )* -> ^( POLYNOMIAL term ( SIGN term )* ) ;
    public final polynomial_return polynomial(String fnt, String fvt) throws RecognitionException {
        polynomial_return retval = new polynomial_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token SIGN29=null;
        term_return term28 = null;

        term_return term30 = null;


        Object SIGN29_tree=null;
        RewriteRuleTokenStream stream_SIGN=new RewriteRuleTokenStream(adaptor,"token SIGN");
        RewriteRuleSubtreeStream stream_term=new RewriteRuleSubtreeStream(adaptor,"rule term");
        try { dbg.enterRule("polynomial");
        if ( ruleLevel==0 ) {dbg.commence();}
        ruleLevel++;
        dbg.location(54, 1);

        try {
            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:55:3: ( term[$fnt,$fvt] ( SIGN term[$fnt, $fvt] )* -> ^( POLYNOMIAL term ( SIGN term )* ) )
            dbg.enterAlt(1);

            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:55:5: term[$fnt,$fvt] ( SIGN term[$fnt, $fvt] )*
            {
            dbg.location(55,5);
            pushFollow(FOLLOW_term_in_polynomial368);
            term28=term(fnt, fvt);
            _fsp--;

            stream_term.add(term28.getTree());
            dbg.location(55,21);
            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:55:21: ( SIGN term[$fnt, $fvt] )*
            try { dbg.enterSubRule(3);

            loop3:
            do {
                int alt3=2;
                try { dbg.enterDecision(3);

                int LA3_0 = input.LA(1);

                if ( (LA3_0==SIGN) ) {
                    alt3=1;
                }


                } finally {dbg.exitDecision(3);}

                switch (alt3) {
            	case 1 :
            	    dbg.enterAlt(1);

            	    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:55:22: SIGN term[$fnt, $fvt]
            	    {
            	    dbg.location(55,22);
            	    SIGN29=(Token)input.LT(1);
            	    match(input,SIGN,FOLLOW_SIGN_in_polynomial372); 
            	    stream_SIGN.add(SIGN29);

            	    dbg.location(55,27);
            	    pushFollow(FOLLOW_term_in_polynomial374);
            	    term30=term(fnt,  , fvt);
            	    _fsp--;

            	    stream_term.add(term30.getTree());

            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);
            } finally {dbg.exitSubRule(3);}

            dbg.location(56,5);

            // AST REWRITE
            // elements: term, term, SIGN
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 56:5: -> ^( POLYNOMIAL term ( SIGN term )* )
            {
                dbg.location(56,8);
                // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:56:8: ^( POLYNOMIAL term ( SIGN term )* )
                {
                Object root_1 = (Object)adaptor.nil();
                dbg.location(56,10);
                root_1 = (Object)adaptor.becomeRoot(adaptor.create(POLYNOMIAL, "POLYNOMIAL"), root_1);

                dbg.location(56,21);
                adaptor.addChild(root_1, stream_term.next());
                dbg.location(56,26);
                // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:56:26: ( SIGN term )*
                while ( stream_term.hasNext()||stream_SIGN.hasNext() ) {
                    dbg.location(56,27);
                    adaptor.addChild(root_1, stream_SIGN.next());
                    dbg.location(56,32);
                    adaptor.addChild(root_1, stream_term.next());

                }
                stream_term.reset();
                stream_SIGN.reset();

                adaptor.addChild(root_0, root_1);
                }

            }



            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        dbg.location(56, 39);

        }
        finally {
            dbg.exitRule("polynomial");
            ruleLevel--;
            if ( ruleLevel==0 ) {dbg.terminate();}
        }

        return retval;
    }
    // $ANTLR end polynomial

    public static class print_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start print
    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:58:1: print : PRINT ( printTarget )* terminator -> ^( PRINT ( printTarget )* ) ;
    public final print_return print() throws RecognitionException {
        print_return retval = new print_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token PRINT31=null;
        printTarget_return printTarget32 = null;

        terminator_return terminator33 = null;


        Object PRINT31_tree=null;
        RewriteRuleTokenStream stream_PRINT=new RewriteRuleTokenStream(adaptor,"token PRINT");
        RewriteRuleSubtreeStream stream_terminator=new RewriteRuleSubtreeStream(adaptor,"rule terminator");
        RewriteRuleSubtreeStream stream_printTarget=new RewriteRuleSubtreeStream(adaptor,"rule printTarget");
        try { dbg.enterRule("print");
        if ( ruleLevel==0 ) {dbg.commence();}
        ruleLevel++;
        dbg.location(58, 1);

        try {
            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:59:3: ( PRINT ( printTarget )* terminator -> ^( PRINT ( printTarget )* ) )
            dbg.enterAlt(1);

            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:59:5: PRINT ( printTarget )* terminator
            {
            dbg.location(59,5);
            PRINT31=(Token)input.LT(1);
            match(input,PRINT,FOLLOW_PRINT_in_print408); 
            stream_PRINT.add(PRINT31);

            dbg.location(59,11);
            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:59:11: ( printTarget )*
            try { dbg.enterSubRule(4);

            loop4:
            do {
                int alt4=2;
                try { dbg.enterDecision(4);

                int LA4_0 = input.LA(1);

                if ( (LA4_0==NUMBER||LA4_0==NAME||LA4_0==STRING_LITERAL) ) {
                    alt4=1;
                }


                } finally {dbg.exitDecision(4);}

                switch (alt4) {
            	case 1 :
            	    dbg.enterAlt(1);

            	    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:59:11: printTarget
            	    {
            	    dbg.location(59,11);
            	    pushFollow(FOLLOW_printTarget_in_print410);
            	    printTarget32=printTarget();
            	    _fsp--;

            	    stream_printTarget.add(printTarget32.getTree());

            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);
            } finally {dbg.exitSubRule(4);}

            dbg.location(59,24);
            pushFollow(FOLLOW_terminator_in_print413);
            terminator33=terminator();
            _fsp--;

            stream_terminator.add(terminator33.getTree());
            dbg.location(59,35);

            // AST REWRITE
            // elements: PRINT, printTarget
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 59:35: -> ^( PRINT ( printTarget )* )
            {
                dbg.location(59,38);
                // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:59:38: ^( PRINT ( printTarget )* )
                {
                Object root_1 = (Object)adaptor.nil();
                dbg.location(59,40);
                root_1 = (Object)adaptor.becomeRoot(stream_PRINT.next(), root_1);

                dbg.location(59,46);
                // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:59:46: ( printTarget )*
                while ( stream_printTarget.hasNext() ) {
                    dbg.location(59,46);
                    adaptor.addChild(root_1, stream_printTarget.next());

                }
                stream_printTarget.reset();

                adaptor.addChild(root_0, root_1);
                }

            }



            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        dbg.location(59, 59);

        }
        finally {
            dbg.exitRule("print");
            ruleLevel--;
            if ( ruleLevel==0 ) {dbg.terminate();}
        }

        return retval;
    }
    // $ANTLR end print

    public static class printTarget_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start printTarget
    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:61:1: printTarget : ( NUMBER -> NUMBER | sl= STRING_LITERAL -> $sl | NAME -> NAME | NAME LEFT_PAREN RIGHT_PAREN -> ^( FUNCTION NAME ) | functionEval | derivative );
    public final printTarget_return printTarget() throws RecognitionException {
        printTarget_return retval = new printTarget_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token sl=null;
        Token NUMBER34=null;
        Token NAME35=null;
        Token NAME36=null;
        Token LEFT_PAREN37=null;
        Token RIGHT_PAREN38=null;
        functionEval_return functionEval39 = null;

        derivative_return derivative40 = null;


        Object sl_tree=null;
        Object NUMBER34_tree=null;
        Object NAME35_tree=null;
        Object NAME36_tree=null;
        Object LEFT_PAREN37_tree=null;
        Object RIGHT_PAREN38_tree=null;
        RewriteRuleTokenStream stream_LEFT_PAREN=new RewriteRuleTokenStream(adaptor,"token LEFT_PAREN");
        RewriteRuleTokenStream stream_NAME=new RewriteRuleTokenStream(adaptor,"token NAME");
        RewriteRuleTokenStream stream_RIGHT_PAREN=new RewriteRuleTokenStream(adaptor,"token RIGHT_PAREN");
        RewriteRuleTokenStream stream_NUMBER=new RewriteRuleTokenStream(adaptor,"token NUMBER");
        RewriteRuleTokenStream stream_STRING_LITERAL=new RewriteRuleTokenStream(adaptor,"token STRING_LITERAL");

        try { dbg.enterRule("printTarget");
        if ( ruleLevel==0 ) {dbg.commence();}
        ruleLevel++;
        dbg.location(61, 1);

        try {
            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:62:3: ( NUMBER -> NUMBER | sl= STRING_LITERAL -> $sl | NAME -> NAME | NAME LEFT_PAREN RIGHT_PAREN -> ^( FUNCTION NAME ) | functionEval | derivative )
            int alt5=6;
            try { dbg.enterDecision(5);

            switch ( input.LA(1) ) {
            case NUMBER:
                {
                alt5=1;
                }
                break;
            case STRING_LITERAL:
                {
                alt5=2;
                }
                break;
            case NAME:
                {
                switch ( input.LA(2) ) {
                case LEFT_PAREN:
                    {
                    int LA5_4 = input.LA(3);

                    if ( (LA5_4==RIGHT_PAREN) ) {
                        alt5=4;
                    }
                    else if ( (LA5_4==NUMBER||LA5_4==NAME) ) {
                        alt5=5;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("61:1: printTarget : ( NUMBER -> NUMBER | sl= STRING_LITERAL -> $sl | NAME -> NAME | NAME LEFT_PAREN RIGHT_PAREN -> ^( FUNCTION NAME ) | functionEval | derivative );", 5, 4, input);

                        dbg.recognitionException(nvae);
                        throw nvae;
                    }
                    }
                    break;
                case APOSTROPHE:
                    {
                    alt5=6;
                    }
                    break;
                case EOF:
                case NUMBER:
                case NAME:
                case STRING_LITERAL:
                case NEWLINE:
                    {
                    alt5=3;
                    }
                    break;
                default:
                    NoViableAltException nvae =
                        new NoViableAltException("61:1: printTarget : ( NUMBER -> NUMBER | sl= STRING_LITERAL -> $sl | NAME -> NAME | NAME LEFT_PAREN RIGHT_PAREN -> ^( FUNCTION NAME ) | functionEval | derivative );", 5, 3, input);

                    dbg.recognitionException(nvae);
                    throw nvae;
                }

                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("61:1: printTarget : ( NUMBER -> NUMBER | sl= STRING_LITERAL -> $sl | NAME -> NAME | NAME LEFT_PAREN RIGHT_PAREN -> ^( FUNCTION NAME ) | functionEval | derivative );", 5, 0, input);

                dbg.recognitionException(nvae);
                throw nvae;
            }

            } finally {dbg.exitDecision(5);}

            switch (alt5) {
                case 1 :
                    dbg.enterAlt(1);

                    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:62:5: NUMBER
                    {
                    dbg.location(62,5);
                    NUMBER34=(Token)input.LT(1);
                    match(input,NUMBER,FOLLOW_NUMBER_in_printTarget434); 
                    stream_NUMBER.add(NUMBER34);

                    dbg.location(62,12);

                    // AST REWRITE
                    // elements: NUMBER
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 62:12: -> NUMBER
                    {
                        dbg.location(62,15);
                        adaptor.addChild(root_0, stream_NUMBER.next());

                    }



                    }
                    break;
                case 2 :
                    dbg.enterAlt(2);

                    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:63:5: sl= STRING_LITERAL
                    {
                    dbg.location(63,7);
                    sl=(Token)input.LT(1);
                    match(input,STRING_LITERAL,FOLLOW_STRING_LITERAL_in_printTarget446); 
                    stream_STRING_LITERAL.add(sl);

                    dbg.location(63,23);

                    // AST REWRITE
                    // elements: sl
                    // token labels: sl
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleTokenStream stream_sl=new RewriteRuleTokenStream(adaptor,"token sl",sl);
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 63:23: -> $sl
                    {
                        dbg.location(63,26);
                        adaptor.addChild(root_0, stream_sl.next());

                    }



                    }
                    break;
                case 3 :
                    dbg.enterAlt(3);

                    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:64:5: NAME
                    {
                    dbg.location(64,5);
                    NAME35=(Token)input.LT(1);
                    match(input,NAME,FOLLOW_NAME_in_printTarget457); 
                    stream_NAME.add(NAME35);

                    dbg.location(64,10);

                    // AST REWRITE
                    // elements: NAME
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 64:10: -> NAME
                    {
                        dbg.location(64,13);
                        adaptor.addChild(root_0, stream_NAME.next());

                    }



                    }
                    break;
                case 4 :
                    dbg.enterAlt(4);

                    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:69:5: NAME LEFT_PAREN RIGHT_PAREN
                    {
                    dbg.location(69,5);
                    NAME36=(Token)input.LT(1);
                    match(input,NAME,FOLLOW_NAME_in_printTarget479); 
                    stream_NAME.add(NAME36);

                    dbg.location(69,10);
                    LEFT_PAREN37=(Token)input.LT(1);
                    match(input,LEFT_PAREN,FOLLOW_LEFT_PAREN_in_printTarget481); 
                    stream_LEFT_PAREN.add(LEFT_PAREN37);

                    dbg.location(69,21);
                    RIGHT_PAREN38=(Token)input.LT(1);
                    match(input,RIGHT_PAREN,FOLLOW_RIGHT_PAREN_in_printTarget483); 
                    stream_RIGHT_PAREN.add(RIGHT_PAREN38);

                    dbg.location(69,33);

                    // AST REWRITE
                    // elements: NAME
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 69:33: -> ^( FUNCTION NAME )
                    {
                        dbg.location(69,36);
                        // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:69:36: ^( FUNCTION NAME )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        dbg.location(69,38);
                        root_1 = (Object)adaptor.becomeRoot(adaptor.create(FUNCTION, "FUNCTION"), root_1);

                        dbg.location(69,47);
                        adaptor.addChild(root_1, stream_NAME.next());

                        adaptor.addChild(root_0, root_1);
                        }

                    }



                    }
                    break;
                case 5 :
                    dbg.enterAlt(5);

                    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:70:5: functionEval
                    {
                    root_0 = (Object)adaptor.nil();

                    dbg.location(70,5);
                    pushFollow(FOLLOW_functionEval_in_printTarget497);
                    functionEval39=functionEval();
                    _fsp--;

                    adaptor.addChild(root_0, functionEval39.getTree());

                    }
                    break;
                case 6 :
                    dbg.enterAlt(6);

                    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:71:5: derivative
                    {
                    root_0 = (Object)adaptor.nil();

                    dbg.location(71,5);
                    pushFollow(FOLLOW_derivative_in_printTarget503);
                    derivative40=derivative();
                    _fsp--;

                    adaptor.addChild(root_0, derivative40.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        dbg.location(72, 3);

        }
        finally {
            dbg.exitRule("printTarget");
            ruleLevel--;
            if ( ruleLevel==0 ) {dbg.terminate();}
        }

        return retval;
    }
    // $ANTLR end printTarget

    public static class script_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start script
    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:75:1: script : ( statement )* EOF ;
    public final script_return script() throws RecognitionException {
        script_return retval = new script_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token EOF42=null;
        statement_return statement41 = null;


        Object EOF42_tree=null;

        try { dbg.enterRule("script");
        if ( ruleLevel==0 ) {dbg.commence();}
        ruleLevel++;
        dbg.location(75, 1);

        try {
            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:75:7: ( ( statement )* EOF )
            dbg.enterAlt(1);

            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:75:9: ( statement )* EOF
            {
            root_0 = (Object)adaptor.nil();

            dbg.location(75,9);
            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:75:9: ( statement )*
            try { dbg.enterSubRule(6);

            loop6:
            do {
                int alt6=2;
                try { dbg.enterDecision(6);

                int LA6_0 = input.LA(1);

                if ( (LA6_0==HELP||(LA6_0>=LIST && LA6_0<=PRINT)||LA6_0==NAME) ) {
                    alt6=1;
                }


                } finally {dbg.exitDecision(6);}

                switch (alt6) {
            	case 1 :
            	    dbg.enterAlt(1);

            	    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:75:9: statement
            	    {
            	    dbg.location(75,9);
            	    pushFollow(FOLLOW_statement_in_script514);
            	    statement41=statement();
            	    _fsp--;

            	    adaptor.addChild(root_0, statement41.getTree());

            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);
            } finally {dbg.exitSubRule(6);}

            dbg.location(75,23);
            EOF42=(Token)input.LT(1);
            match(input,EOF,FOLLOW_EOF_in_script517); 

            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        dbg.location(75, 24);

        }
        finally {
            dbg.exitRule("script");
            ruleLevel--;
            if ( ruleLevel==0 ) {dbg.terminate();}
        }

        return retval;
    }
    // $ANTLR end script

    public static class statement_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start statement
    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:77:1: statement : ( assign | combine | define | interactiveStatement | print );
    public final statement_return statement() throws RecognitionException {
        statement_return retval = new statement_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        assign_return assign43 = null;

        combine_return combine44 = null;

        define_return define45 = null;

        interactiveStatement_return interactiveStatement46 = null;

        print_return print47 = null;



        try { dbg.enterRule("statement");
        if ( ruleLevel==0 ) {dbg.commence();}
        ruleLevel++;
        dbg.location(77, 1);

        try {
            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:78:3: ( assign | combine | define | interactiveStatement | print )
            int alt7=5;
            try { dbg.enterDecision(7);

            switch ( input.LA(1) ) {
            case NAME:
                {
                int LA7_1 = input.LA(2);

                if ( (LA7_1==ASSIGN) ) {
                    int LA7_4 = input.LA(3);

                    if ( (LA7_4==NAME) ) {
                        int LA7_6 = input.LA(4);

                        if ( (LA7_6==EOF||LA7_6==LEFT_PAREN||LA7_6==NEWLINE) ) {
                            alt7=1;
                        }
                        else if ( (LA7_6==SIGN) ) {
                            alt7=2;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("77:1: statement : ( assign | combine | define | interactiveStatement | print );", 7, 6, input);

                            dbg.recognitionException(nvae);
                            throw nvae;
                        }
                    }
                    else if ( (LA7_4==NUMBER) ) {
                        alt7=1;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("77:1: statement : ( assign | combine | define | interactiveStatement | print );", 7, 4, input);

                        dbg.recognitionException(nvae);
                        throw nvae;
                    }
                }
                else if ( (LA7_1==LEFT_PAREN) ) {
                    alt7=3;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("77:1: statement : ( assign | combine | define | interactiveStatement | print );", 7, 1, input);

                    dbg.recognitionException(nvae);
                    throw nvae;
                }
                }
                break;
            case HELP:
            case LIST:
                {
                alt7=4;
                }
                break;
            case PRINT:
                {
                alt7=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("77:1: statement : ( assign | combine | define | interactiveStatement | print );", 7, 0, input);

                dbg.recognitionException(nvae);
                throw nvae;
            }

            } finally {dbg.exitDecision(7);}

            switch (alt7) {
                case 1 :
                    dbg.enterAlt(1);

                    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:78:5: assign
                    {
                    root_0 = (Object)adaptor.nil();

                    dbg.location(78,5);
                    pushFollow(FOLLOW_assign_in_statement528);
                    assign43=assign();
                    _fsp--;

                    adaptor.addChild(root_0, assign43.getTree());

                    }
                    break;
                case 2 :
                    dbg.enterAlt(2);

                    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:79:5: combine
                    {
                    root_0 = (Object)adaptor.nil();

                    dbg.location(79,5);
                    pushFollow(FOLLOW_combine_in_statement534);
                    combine44=combine();
                    _fsp--;

                    adaptor.addChild(root_0, combine44.getTree());

                    }
                    break;
                case 3 :
                    dbg.enterAlt(3);

                    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:80:5: define
                    {
                    root_0 = (Object)adaptor.nil();

                    dbg.location(80,5);
                    pushFollow(FOLLOW_define_in_statement540);
                    define45=define();
                    _fsp--;

                    adaptor.addChild(root_0, define45.getTree());

                    }
                    break;
                case 4 :
                    dbg.enterAlt(4);

                    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:82:34: interactiveStatement
                    {
                    root_0 = (Object)adaptor.nil();

                    dbg.location(82,34);
                    pushFollow(FOLLOW_interactiveStatement_in_statement551);
                    interactiveStatement46=interactiveStatement();
                    _fsp--;

                    adaptor.addChild(root_0, interactiveStatement46.getTree());

                    }
                    break;
                case 5 :
                    dbg.enterAlt(5);

                    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:83:5: print
                    {
                    root_0 = (Object)adaptor.nil();

                    dbg.location(83,5);
                    pushFollow(FOLLOW_print_in_statement557);
                    print47=print();
                    _fsp--;

                    adaptor.addChild(root_0, print47.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        dbg.location(84, 3);

        }
        finally {
            dbg.exitRule("statement");
            ruleLevel--;
            if ( ruleLevel==0 ) {dbg.terminate();}
        }

        return retval;
    }
    // $ANTLR end statement

    public static class term_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start term
    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:87:1: term[String fnt, String fvt] : (c= coefficient )? (tv= NAME (e= exponent )? )? {...}? -> ^( TERM ( $c)? ( $tv)? ( $e)? ) ;
    public final term_return term(String fnt, String fvt) throws RecognitionException {
        term_return retval = new term_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token tv=null;
        coefficient_return c = null;

        exponent_return e = null;


        Object tv_tree=null;
        RewriteRuleTokenStream stream_NAME=new RewriteRuleTokenStream(adaptor,"token NAME");
        RewriteRuleSubtreeStream stream_exponent=new RewriteRuleSubtreeStream(adaptor,"rule exponent");
        RewriteRuleSubtreeStream stream_coefficient=new RewriteRuleSubtreeStream(adaptor,"rule coefficient");
        try { dbg.enterRule("term");
        if ( ruleLevel==0 ) {dbg.commence();}
        ruleLevel++;
        dbg.location(87, 1);

        try {
            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:89:3: ( (c= coefficient )? (tv= NAME (e= exponent )? )? {...}? -> ^( TERM ( $c)? ( $tv)? ( $e)? ) )
            dbg.enterAlt(1);

            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:89:5: (c= coefficient )? (tv= NAME (e= exponent )? )? {...}?
            {
            dbg.location(89,6);
            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:89:6: (c= coefficient )?
            int alt8=2;
            try { dbg.enterSubRule(8);
            try { dbg.enterDecision(8);

            int LA8_0 = input.LA(1);

            if ( (LA8_0==NUMBER) ) {
                alt8=1;
            }
            } finally {dbg.exitDecision(8);}

            switch (alt8) {
                case 1 :
                    dbg.enterAlt(1);

                    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:89:6: c= coefficient
                    {
                    dbg.location(89,6);
                    pushFollow(FOLLOW_coefficient_in_term577);
                    c=coefficient();
                    _fsp--;

                    stream_coefficient.add(c.getTree());

                    }
                    break;

            }
            } finally {dbg.exitSubRule(8);}

            dbg.location(89,20);
            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:89:20: (tv= NAME (e= exponent )? )?
            int alt10=2;
            try { dbg.enterSubRule(10);
            try { dbg.enterDecision(10);

            int LA10_0 = input.LA(1);

            if ( (LA10_0==NAME) ) {
                alt10=1;
            }
            } finally {dbg.exitDecision(10);}

            switch (alt10) {
                case 1 :
                    dbg.enterAlt(1);

                    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:89:21: tv= NAME (e= exponent )?
                    {
                    dbg.location(89,23);
                    tv=(Token)input.LT(1);
                    match(input,NAME,FOLLOW_NAME_in_term583); 
                    stream_NAME.add(tv);

                    dbg.location(89,30);
                    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:89:30: (e= exponent )?
                    int alt9=2;
                    try { dbg.enterSubRule(9);
                    try { dbg.enterDecision(9);

                    int LA9_0 = input.LA(1);

                    if ( (LA9_0==CARET) ) {
                        alt9=1;
                    }
                    } finally {dbg.exitDecision(9);}

                    switch (alt9) {
                        case 1 :
                            dbg.enterAlt(1);

                            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:89:30: e= exponent
                            {
                            dbg.location(89,30);
                            pushFollow(FOLLOW_exponent_in_term587);
                            e=exponent();
                            _fsp--;

                            stream_exponent.add(e.getTree());

                            }
                            break;

                    }
                    } finally {dbg.exitSubRule(9);}


                    }
                    break;

            }
            } finally {dbg.exitSubRule(10);}

            dbg.location(92,5);
            if ( !(evalPredicate( tv == null ? true : (tv.getText()).equals(fvt) ," tv == null ? true : ($tv.text).equals($fvt) ")) ) {
                throw new FailedPredicateException(input, "term", " tv == null ? true : ($tv.text).equals($fvt) ");
            }
            dbg.location(93,5);

            // AST REWRITE
            // elements: e, c, tv
            // token labels: tv
            // rule labels: c, retval, e
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleTokenStream stream_tv=new RewriteRuleTokenStream(adaptor,"token tv",tv);
            RewriteRuleSubtreeStream stream_c=new RewriteRuleSubtreeStream(adaptor,"token c",c!=null?c.tree:null);
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);
            RewriteRuleSubtreeStream stream_e=new RewriteRuleSubtreeStream(adaptor,"token e",e!=null?e.tree:null);

            root_0 = (Object)adaptor.nil();
            // 93:5: -> ^( TERM ( $c)? ( $tv)? ( $e)? )
            {
                dbg.location(93,8);
                // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:93:8: ^( TERM ( $c)? ( $tv)? ( $e)? )
                {
                Object root_1 = (Object)adaptor.nil();
                dbg.location(93,10);
                root_1 = (Object)adaptor.becomeRoot(adaptor.create(TERM, "TERM"), root_1);

                dbg.location(93,15);
                // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:93:15: ( $c)?
                if ( stream_c.hasNext() ) {
                    dbg.location(93,15);
                    adaptor.addChild(root_1, stream_c.next());

                }
                stream_c.reset();
                dbg.location(93,19);
                // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:93:19: ( $tv)?
                if ( stream_tv.hasNext() ) {
                    dbg.location(93,19);
                    adaptor.addChild(root_1, stream_tv.next());

                }
                stream_tv.reset();
                dbg.location(93,24);
                // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:93:24: ( $e)?
                if ( stream_e.hasNext() ) {
                    dbg.location(93,24);
                    adaptor.addChild(root_1, stream_e.next());

                }
                stream_e.reset();

                adaptor.addChild(root_0, root_1);
                }

            }



            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (FailedPredicateException fpe) {

                String tvt = tv.getText();
                String msg = "In function \"" + fnt +
                  "\" the term variable \"" + tvt +
                  "\" doesn't match function variable \"" + fvt + "\".";
                throw new RuntimeException(msg);
              
        }
        finally {
        }
        dbg.location(94, 3);

        }
        finally {
            dbg.exitRule("term");
            ruleLevel--;
            if ( ruleLevel==0 ) {dbg.terminate();}
        }

        return retval;
    }
    // $ANTLR end term

    public static class terminator_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start terminator
    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:107:1: terminator : ( NEWLINE | EOF );
    public final terminator_return terminator() throws RecognitionException {
        terminator_return retval = new terminator_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token set48=null;

        Object set48_tree=null;

        try { dbg.enterRule("terminator");
        if ( ruleLevel==0 ) {dbg.commence();}
        ruleLevel++;
        dbg.location(107, 1);

        try {
            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:107:11: ( NEWLINE | EOF )
            dbg.enterAlt(1);

            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:
            {
            root_0 = (Object)adaptor.nil();

            dbg.location(107,11);
            set48=(Token)input.LT(1);
            if ( input.LA(1)==EOF||input.LA(1)==NEWLINE ) {
                input.consume();
                adaptor.addChild(root_0, adaptor.create(set48));
                errorRecovery=false;
            }
            else {
                MismatchedSetException mse =
                    new MismatchedSetException(null,input);
                dbg.recognitionException(mse);
                recoverFromMismatchedSet(input,mse,FOLLOW_set_in_terminator0);    throw mse;
            }


            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        dbg.location(107, 26);

        }
        finally {
            dbg.exitRule("terminator");
            ruleLevel--;
            if ( ruleLevel==0 ) {dbg.terminate();}
        }

        return retval;
    }
    // $ANTLR end terminator

    public static class value_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start value
    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:109:1: value : ( NUMBER | NAME | fe= functionEval );
    public final value_return value() throws RecognitionException {
        value_return retval = new value_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token NUMBER49=null;
        Token NAME50=null;
        functionEval_return fe = null;


        Object NUMBER49_tree=null;
        Object NAME50_tree=null;

        try { dbg.enterRule("value");
        if ( ruleLevel==0 ) {dbg.commence();}
        ruleLevel++;
        dbg.location(109, 1);

        try {
            // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:109:6: ( NUMBER | NAME | fe= functionEval )
            int alt11=3;
            try { dbg.enterDecision(11);

            int LA11_0 = input.LA(1);

            if ( (LA11_0==NUMBER) ) {
                alt11=1;
            }
            else if ( (LA11_0==NAME) ) {
                int LA11_2 = input.LA(2);

                if ( (LA11_2==LEFT_PAREN) ) {
                    alt11=3;
                }
                else if ( (LA11_2==EOF||LA11_2==NEWLINE) ) {
                    alt11=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("109:1: value : ( NUMBER | NAME | fe= functionEval );", 11, 2, input);

                    dbg.recognitionException(nvae);
                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("109:1: value : ( NUMBER | NAME | fe= functionEval );", 11, 0, input);

                dbg.recognitionException(nvae);
                throw nvae;
            }
            } finally {dbg.exitDecision(11);}

            switch (alt11) {
                case 1 :
                    dbg.enterAlt(1);

                    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:109:8: NUMBER
                    {
                    root_0 = (Object)adaptor.nil();

                    dbg.location(109,8);
                    NUMBER49=(Token)input.LT(1);
                    match(input,NUMBER,FOLLOW_NUMBER_in_value663); 
                    NUMBER49_tree = (Object)adaptor.create(NUMBER49);
                    adaptor.addChild(root_0, NUMBER49_tree);


                    }
                    break;
                case 2 :
                    dbg.enterAlt(2);

                    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:109:17: NAME
                    {
                    root_0 = (Object)adaptor.nil();

                    dbg.location(109,17);
                    NAME50=(Token)input.LT(1);
                    match(input,NAME,FOLLOW_NAME_in_value667); 
                    NAME50_tree = (Object)adaptor.create(NAME50);
                    adaptor.addChild(root_0, NAME50_tree);


                    }
                    break;
                case 3 :
                    dbg.enterAlt(3);

                    // /Users/Mark/Documents/Programming/ANTLR/Math/MathParser.g:109:24: fe= functionEval
                    {
                    root_0 = (Object)adaptor.nil();

                    dbg.location(109,26);
                    pushFollow(FOLLOW_functionEval_in_value673);
                    fe=functionEval();
                    _fsp--;

                    adaptor.addChild(root_0, fe.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        dbg.location(109, 39);

        }
        finally {
            dbg.exitRule("value");
            ruleLevel--;
            if ( ruleLevel==0 ) {dbg.terminate();}
        }

        return retval;
    }
    // $ANTLR end value


 

    public static final BitSet FOLLOW_NAME_in_assign89 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_ASSIGN_in_assign91 = new BitSet(new long[]{0x0000000000500000L});
    public static final BitSet FOLLOW_value_in_assign93 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_terminator_in_assign95 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NUMBER_in_coefficient112 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NAME_in_combine124 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_ASSIGN_in_combine126 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_NAME_in_combine130 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_SIGN_in_combine134 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_NAME_in_combine138 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_terminator_in_combine140 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NAME_in_define174 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_LEFT_PAREN_in_define176 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_NAME_in_define180 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_RIGHT_PAREN_in_define182 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_ASSIGN_in_define184 = new BitSet(new long[]{0x0000000002510000L});
    public static final BitSet FOLLOW_polynomial_in_define190 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_terminator_in_define193 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NAME_in_derivative225 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_APOSTROPHE_in_derivative227 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_LEFT_PAREN_in_derivative229 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_RIGHT_PAREN_in_derivative231 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CARET_in_exponent247 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_NUMBER_in_exponent249 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NAME_in_functionEval265 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_LEFT_PAREN_in_functionEval267 = new BitSet(new long[]{0x0000000000500000L});
    public static final BitSet FOLLOW_NUMBER_in_functionEval272 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_NAME_in_functionEval278 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_RIGHT_PAREN_in_functionEval281 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_HELP_in_help302 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_terminator_in_help304 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_help_in_interactiveStatement317 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_list_in_interactiveStatement321 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LIST_in_list333 = new BitSet(new long[]{0x0000000000020200L});
    public static final BitSet FOLLOW_listOption_in_list335 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_terminator_in_list337 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_listOption0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_term_in_polynomial368 = new BitSet(new long[]{0x0000000000010002L});
    public static final BitSet FOLLOW_SIGN_in_polynomial372 = new BitSet(new long[]{0x0000000000510002L});
    public static final BitSet FOLLOW_term_in_polynomial374 = new BitSet(new long[]{0x0000000000010002L});
    public static final BitSet FOLLOW_PRINT_in_print408 = new BitSet(new long[]{0x0000000003500000L});
    public static final BitSet FOLLOW_printTarget_in_print410 = new BitSet(new long[]{0x0000000003500000L});
    public static final BitSet FOLLOW_terminator_in_print413 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NUMBER_in_printTarget434 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRING_LITERAL_in_printTarget446 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NAME_in_printTarget457 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NAME_in_printTarget479 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_LEFT_PAREN_in_printTarget481 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_RIGHT_PAREN_in_printTarget483 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_functionEval_in_printTarget497 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_derivative_in_printTarget503 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_statement_in_script514 = new BitSet(new long[]{0x0000000000403400L});
    public static final BitSet FOLLOW_EOF_in_script517 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_assign_in_statement528 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_combine_in_statement534 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_define_in_statement540 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_interactiveStatement_in_statement551 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_print_in_statement557 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_coefficient_in_term577 = new BitSet(new long[]{0x0000000000400002L});
    public static final BitSet FOLLOW_NAME_in_term583 = new BitSet(new long[]{0x0000000000000102L});
    public static final BitSet FOLLOW_exponent_in_term587 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_terminator0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NUMBER_in_value663 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NAME_in_value667 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_functionEval_in_value673 = new BitSet(new long[]{0x0000000000000002L});

}